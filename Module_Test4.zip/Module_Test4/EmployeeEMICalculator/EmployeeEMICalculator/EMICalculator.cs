﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeEMICalculator
{
    public partial class EMICalculator : Form
    {
        long id, mobile;
        string name, email, gender, department, dob, hobbies = "";

        private void tabSalary_Click(object sender, EventArgs e)
        {
            grpDetails.Visible = false;
        }

        private void EMICalculator_Load(object sender, EventArgs e)
        {
            grpDetails.Visible = false;
        }

        private void txtID_MouseHover(object sender, EventArgs e)
        {
            toolStripMessage.Text = "Enter Employee ID";
        }

        private void txtName_MouseHover(object sender, EventArgs e)
        {
            toolStripMessage.Text = "Enter Employee Name";
        }

        private void cmbDept_MouseHover(object sender, EventArgs e)
        {
            toolStripMessage.Text = "Select Department";
        }

        private void txtEmail_MouseHover(object sender, EventArgs e)
        {
            toolStripMessage.Text = "Enter Email Address";
        }

        private void txtMobile_MouseHover(object sender, EventArgs e)
        {
            toolStripMessage.Text = "Enter Mobile Number";
        }

        private void grpGender_MouseHover(object sender, EventArgs e)
        {
            toolStripMessage.Text = "Select Gender";
        }

        private void dateDOB_MouseHover(object sender, EventArgs e)
        {
            toolStripMessage.Text = "Select Date of Birth";
        }

        private void grpHobbies_MouseHover(object sender, EventArgs e)
        {
            toolStripMessage.Text = "Select Hobbies";
        }

        private void btnView_MouseHover(object sender, EventArgs e)
        {
            toolStripMessage.Text = "View Personal Details";
        }

        private void txtBasicSalary_MouseHover(object sender, EventArgs e)
        {
            toolStripMessage2.Text = "Enter Basic Salary";

        }

        private void txLoanAmount_MouseHover(object sender, EventArgs e)
        {
            toolStripMessage2.Text = "Enter Loan amount";
        }

        private void txtLoanTenure_MouseHover(object sender, EventArgs e)
        {
            toolStripMessage2.Text = "Enter Loan Tenure";
        }

        private void txtRateOfInterest_MouseHover(object sender, EventArgs e)
        {
            toolStripMessage2.Text = "Enter Rate of Interest Per Annum";
        }

        private void btnEMI_MouseHover(object sender, EventArgs e)
        {
            toolStripMessage2.Text = "Calculate EMI";
        }

        private void tabSalary_MouseHover(object sender, EventArgs e)
        {
       
            toolStripMessage2.Text = "";
        }

        private void tabPersonal_MouseHover(object sender, EventArgs e)
        {
            toolStripMessage.Text = "";
         
        }

        private void statusStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        double rateOfInterestAnnum, rateOfInterest, emi, basicSalary, da, gp, amount, tenure, numberOfMonths;
        double totalSalary;

        private void btnEMI_Click(object sender, EventArgs e)
        {
            grpDetails.Visible = true;

            try
            {
                basicSalary = Convert.ToDouble(txtBasicSalary.Text);
                da = basicSalary * 30 / 100;
                gp = basicSalary + da;
                amount = Convert.ToDouble(txLoanAmount.Text);
                tenure = Convert.ToDouble(txtLoanTenure.Text);
                rateOfInterestAnnum = Convert.ToDouble(txtRateOfInterest.Text);
                rateOfInterest = rateOfInterestAnnum / (12 * 100);
                numberOfMonths = tenure * 12;
                emi = (amount * rateOfInterest * Math.Pow((1 * rateOfInterest), numberOfMonths) / Math.Pow((1 + rateOfInterest), numberOfMonths));
                totalSalary = gp - emi;

                lblID.Text = id.ToString();
                lblName.Text = name.ToString();

            }
            catch(Exception ex)
            {
                lblMessage2.Text = "Please Enter Details Correctly.";
            }
            
           
            lblBasicSalary.Text = basicSalary.ToString();
            lblDA.Text = da.ToString();
            lblGrossSalary.Text = gp.ToString();
            lblAmount.Text = amount.ToString();
            lblTenure.Text = tenure.ToString();
            lblRateOfInterest.Text = rateOfInterestAnnum.ToString();
            lblEMI.Text = emi.ToString();
            lblTotal.Text = totalSalary.ToString();


        }

        public EMICalculator()
        {
            InitializeComponent();
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            
            try
            {
                id = Convert.ToInt64(txtID.Text);             
                name = txtName.Text;
                email = txtEmail.Text;
                mobile = Convert.ToInt64(txtMobile.Text);
                if (radioMale.Checked)
                {
                    gender = "Male";
                }
                else
                {
                    gender = "Female";
                }
                dob = dateDOB.Value.ToString("dd-MM-yyyy");
                if (chkReading.Checked)
                {
                    hobbies += "Reading,";
                    chkReading.Enabled = false;
                }
                if (chkPlaying.Checked)
                {
                    hobbies += "Playing,";
                    chkPlaying.Enabled = false;
                }

                if (chkTravel.Checked)
                {
                    hobbies += "Travel,";
                    chkTravel.Enabled = false;
                }
                if (chkOthers.Checked)
                {
                    hobbies += "Others";
                    chkOthers.Enabled = false;
                }

                department = cmbDept.Text;

                if (ValidateForm())
                {
                    string message = "Employee ID : " + id + "\nName : " + name + "\nEmail ID :" + email + "\nMobile Number : " + mobile + "\nGender : " + gender + "\nDate of Birth : " + dob + "\nHobbies : " + hobbies + "\n";
                    MessageBox.Show(message, "Personal Details", MessageBoxButtons.OK);

                }

            }
         
            catch(FormatException ex)
            {
                lblMessage1.Text = "Please Enter the Details in Correct Format.";
            }
            catch (Exception ex)
            {
                lblMessage1.Text = "Please Enter the Details Correctly.";
            }

           



        }

        public bool ValidateForm()
        {
            string message="";
            bool flag = true;
        
            if (mobile.ToString().Length != 10 || mobile.ToString().Length==0)
            {
                lblMessage1.Text = "Please Enter Mobile Number Correctly.";
                flag = false;
            }
            else if(!email.Contains('@'))
            {
                lblMessage1.Text = "Please Enter Email ID  Correctly.";
                flag = false;
            }

            return flag;
        }
    }
}
