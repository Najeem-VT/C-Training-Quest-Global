﻿namespace EmployeeEMICalculator
{
    partial class EMICalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EMICalculator));
            this.tabDetails = new System.Windows.Forms.TabControl();
            this.tabPersonal = new System.Windows.Forms.TabPage();
            this.label18 = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripMessage = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblMessage1 = new System.Windows.Forms.Label();
            this.btnView = new System.Windows.Forms.Button();
            this.grpHobbies = new System.Windows.Forms.GroupBox();
            this.chkOthers = new System.Windows.Forms.CheckBox();
            this.chkPlaying = new System.Windows.Forms.CheckBox();
            this.chkTravel = new System.Windows.Forms.CheckBox();
            this.chkReading = new System.Windows.Forms.CheckBox();
            this.dateDOB = new System.Windows.Forms.DateTimePicker();
            this.grpGender = new System.Windows.Forms.GroupBox();
            this.radioFemale = new System.Windows.Forms.RadioButton();
            this.radioMale = new System.Windows.Forms.RadioButton();
            this.txtMobile = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.cmbDept = new System.Windows.Forms.ComboBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtID = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabSalary = new System.Windows.Forms.TabPage();
            this.lblMessage2 = new System.Windows.Forms.Label();
            this.statusStrip2 = new System.Windows.Forms.StatusStrip();
            this.toolStripMessage2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.btnEMI = new System.Windows.Forms.Button();
            this.grpDetails = new System.Windows.Forms.GroupBox();
            this.lblEMI = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblRateOfInterest = new System.Windows.Forms.Label();
            this.lblTenure = new System.Windows.Forms.Label();
            this.lblAmount = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblGrossSalary = new System.Windows.Forms.Label();
            this.lblDA = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.lblBasicSalary = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblID = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtRateOfInterest = new System.Windows.Forms.TextBox();
            this.txtRateOfInterest1 = new System.Windows.Forms.Label();
            this.txtLoanTenure = new System.Windows.Forms.TextBox();
            this.txLoanAmount = new System.Windows.Forms.TextBox();
            this.txtLoanTenure1 = new System.Windows.Forms.Label();
            this.txLoanAmount1 = new System.Windows.Forms.Label();
            this.txtBasicSalary = new System.Windows.Forms.TextBox();
            this.txtBasicSalary1 = new System.Windows.Forms.Label();
            this.lblHeading = new System.Windows.Forms.Label();
            this.tabDetails.SuspendLayout();
            this.tabPersonal.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.grpHobbies.SuspendLayout();
            this.grpGender.SuspendLayout();
            this.tabSalary.SuspendLayout();
            this.statusStrip2.SuspendLayout();
            this.grpDetails.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabDetails
            // 
            this.tabDetails.Controls.Add(this.tabPersonal);
            this.tabDetails.Controls.Add(this.tabSalary);
            this.tabDetails.Location = new System.Drawing.Point(13, 36);
            this.tabDetails.Name = "tabDetails";
            this.tabDetails.SelectedIndex = 0;
            this.tabDetails.Size = new System.Drawing.Size(856, 667);
            this.tabDetails.TabIndex = 0;
            // 
            // tabPersonal
            // 
            this.tabPersonal.Controls.Add(this.label18);
            this.tabPersonal.Controls.Add(this.statusStrip1);
            this.tabPersonal.Controls.Add(this.lblMessage1);
            this.tabPersonal.Controls.Add(this.btnView);
            this.tabPersonal.Controls.Add(this.grpHobbies);
            this.tabPersonal.Controls.Add(this.dateDOB);
            this.tabPersonal.Controls.Add(this.grpGender);
            this.tabPersonal.Controls.Add(this.txtMobile);
            this.tabPersonal.Controls.Add(this.txtEmail);
            this.tabPersonal.Controls.Add(this.cmbDept);
            this.tabPersonal.Controls.Add(this.txtName);
            this.tabPersonal.Controls.Add(this.txtID);
            this.tabPersonal.Controls.Add(this.label8);
            this.tabPersonal.Controls.Add(this.label7);
            this.tabPersonal.Controls.Add(this.label6);
            this.tabPersonal.Controls.Add(this.label5);
            this.tabPersonal.Controls.Add(this.label4);
            this.tabPersonal.Controls.Add(this.label3);
            this.tabPersonal.Controls.Add(this.label2);
            this.tabPersonal.Controls.Add(this.label1);
            this.tabPersonal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPersonal.Location = new System.Drawing.Point(4, 22);
            this.tabPersonal.Name = "tabPersonal";
            this.tabPersonal.Padding = new System.Windows.Forms.Padding(3);
            this.tabPersonal.Size = new System.Drawing.Size(848, 641);
            this.tabPersonal.TabIndex = 0;
            this.tabPersonal.Text = "Personal Details";
            this.tabPersonal.UseVisualStyleBackColor = true;
            this.tabPersonal.MouseHover += new System.EventHandler(this.tabPersonal_MouseHover);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label18.Location = new System.Drawing.Point(424, 310);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(0, 20);
            this.label18.TabIndex = 19;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMessage});
            this.statusStrip1.Location = new System.Drawing.Point(3, 616);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(842, 22);
            this.statusStrip1.TabIndex = 18;
            this.statusStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.statusStrip1_ItemClicked);
            // 
            // toolStripMessage
            // 
            this.toolStripMessage.Name = "toolStripMessage";
            this.toolStripMessage.Size = new System.Drawing.Size(0, 17);
            // 
            // lblMessage1
            // 
            this.lblMessage1.AutoSize = true;
            this.lblMessage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblMessage1.Location = new System.Drawing.Point(163, 22);
            this.lblMessage1.Name = "lblMessage1";
            this.lblMessage1.Size = new System.Drawing.Size(0, 20);
            this.lblMessage1.TabIndex = 17;
            // 
            // btnView
            // 
            this.btnView.BackColor = System.Drawing.Color.ForestGreen;
            this.btnView.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnView.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnView.Location = new System.Drawing.Point(573, 451);
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(125, 36);
            this.btnView.TabIndex = 16;
            this.btnView.Text = "VIEW";
            this.btnView.UseVisualStyleBackColor = false;
            this.btnView.Click += new System.EventHandler(this.btnView_Click);
            this.btnView.MouseHover += new System.EventHandler(this.btnView_MouseHover);
            // 
            // grpHobbies
            // 
            this.grpHobbies.Controls.Add(this.chkOthers);
            this.grpHobbies.Controls.Add(this.chkPlaying);
            this.grpHobbies.Controls.Add(this.chkTravel);
            this.grpHobbies.Controls.Add(this.chkReading);
            this.grpHobbies.Location = new System.Drawing.Point(277, 383);
            this.grpHobbies.Name = "grpHobbies";
            this.grpHobbies.Size = new System.Drawing.Size(266, 67);
            this.grpHobbies.TabIndex = 15;
            this.grpHobbies.TabStop = false;
            this.grpHobbies.MouseHover += new System.EventHandler(this.grpHobbies_MouseHover);
            // 
            // chkOthers
            // 
            this.chkOthers.AutoSize = true;
            this.chkOthers.Location = new System.Drawing.Point(124, 44);
            this.chkOthers.Name = "chkOthers";
            this.chkOthers.Size = new System.Drawing.Size(63, 17);
            this.chkOthers.TabIndex = 3;
            this.chkOthers.Text = "Others";
            this.chkOthers.UseVisualStyleBackColor = true;
            // 
            // chkPlaying
            // 
            this.chkPlaying.AutoSize = true;
            this.chkPlaying.Location = new System.Drawing.Point(7, 44);
            this.chkPlaying.Name = "chkPlaying";
            this.chkPlaying.Size = new System.Drawing.Size(67, 17);
            this.chkPlaying.TabIndex = 2;
            this.chkPlaying.Text = "Playing";
            this.chkPlaying.UseVisualStyleBackColor = true;
            // 
            // chkTravel
            // 
            this.chkTravel.AutoSize = true;
            this.chkTravel.Location = new System.Drawing.Point(124, 10);
            this.chkTravel.Name = "chkTravel";
            this.chkTravel.Size = new System.Drawing.Size(62, 17);
            this.chkTravel.TabIndex = 1;
            this.chkTravel.Text = "Travel";
            this.chkTravel.UseVisualStyleBackColor = true;
            // 
            // chkReading
            // 
            this.chkReading.AutoSize = true;
            this.chkReading.Location = new System.Drawing.Point(7, 10);
            this.chkReading.Name = "chkReading";
            this.chkReading.Size = new System.Drawing.Size(73, 17);
            this.chkReading.TabIndex = 0;
            this.chkReading.Text = "Reading";
            this.chkReading.UseVisualStyleBackColor = true;
            // 
            // dateDOB
            // 
            this.dateDOB.Location = new System.Drawing.Point(277, 343);
            this.dateDOB.Name = "dateDOB";
            this.dateDOB.Size = new System.Drawing.Size(266, 20);
            this.dateDOB.TabIndex = 14;
            this.dateDOB.MouseHover += new System.EventHandler(this.dateDOB_MouseHover);
            // 
            // grpGender
            // 
            this.grpGender.Controls.Add(this.radioFemale);
            this.grpGender.Controls.Add(this.radioMale);
            this.grpGender.Location = new System.Drawing.Point(277, 289);
            this.grpGender.Name = "grpGender";
            this.grpGender.Size = new System.Drawing.Size(266, 32);
            this.grpGender.TabIndex = 13;
            this.grpGender.TabStop = false;
            this.grpGender.MouseHover += new System.EventHandler(this.grpGender_MouseHover);
            // 
            // radioFemale
            // 
            this.radioFemale.AutoSize = true;
            this.radioFemale.Location = new System.Drawing.Point(148, 9);
            this.radioFemale.Name = "radioFemale";
            this.radioFemale.Size = new System.Drawing.Size(65, 17);
            this.radioFemale.TabIndex = 1;
            this.radioFemale.Text = "Female";
            this.radioFemale.UseVisualStyleBackColor = true;
            // 
            // radioMale
            // 
            this.radioMale.AutoSize = true;
            this.radioMale.Checked = true;
            this.radioMale.Location = new System.Drawing.Point(20, 9);
            this.radioMale.Name = "radioMale";
            this.radioMale.Size = new System.Drawing.Size(52, 17);
            this.radioMale.TabIndex = 0;
            this.radioMale.TabStop = true;
            this.radioMale.Text = "Male";
            this.radioMale.UseVisualStyleBackColor = true;
            // 
            // txtMobile
            // 
            this.txtMobile.Location = new System.Drawing.Point(277, 251);
            this.txtMobile.Name = "txtMobile";
            this.txtMobile.Size = new System.Drawing.Size(266, 20);
            this.txtMobile.TabIndex = 12;
            this.txtMobile.MouseHover += new System.EventHandler(this.txtMobile_MouseHover);
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(277, 212);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(266, 20);
            this.txtEmail.TabIndex = 11;
            this.txtEmail.MouseHover += new System.EventHandler(this.txtEmail_MouseHover);
            // 
            // cmbDept
            // 
            this.cmbDept.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDept.FormattingEnabled = true;
            this.cmbDept.Items.AddRange(new object[] {
            "Development Department",
            "Testing Department",
            "Sales Department",
            "Management Department"});
            this.cmbDept.Location = new System.Drawing.Point(277, 170);
            this.cmbDept.Name = "cmbDept";
            this.cmbDept.Size = new System.Drawing.Size(266, 21);
            this.cmbDept.TabIndex = 10;
            this.cmbDept.Text = "Select --";
            this.cmbDept.MouseHover += new System.EventHandler(this.cmbDept_MouseHover);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(277, 125);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(266, 20);
            this.txtName.TabIndex = 9;
            this.txtName.MouseHover += new System.EventHandler(this.txtName_MouseHover);
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(277, 73);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(266, 20);
            this.txtID.TabIndex = 8;
            this.txtID.MouseHover += new System.EventHandler(this.txtID_MouseHover);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(87, 383);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 16);
            this.label8.TabIndex = 7;
            this.label8.Text = "Hobbies";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(87, 343);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 16);
            this.label7.TabIndex = 6;
            this.label7.Text = "Date of Birth";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(87, 296);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Gender";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(86, 251);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Mobile Number";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(87, 212);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Email ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(86, 170);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Department";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(86, 125);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Employee Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(86, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Employee ID";
            // 
            // tabSalary
            // 
            this.tabSalary.Controls.Add(this.lblMessage2);
            this.tabSalary.Controls.Add(this.statusStrip2);
            this.tabSalary.Controls.Add(this.btnEMI);
            this.tabSalary.Controls.Add(this.grpDetails);
            this.tabSalary.Controls.Add(this.txtRateOfInterest);
            this.tabSalary.Controls.Add(this.txtRateOfInterest1);
            this.tabSalary.Controls.Add(this.txtLoanTenure);
            this.tabSalary.Controls.Add(this.txLoanAmount);
            this.tabSalary.Controls.Add(this.txtLoanTenure1);
            this.tabSalary.Controls.Add(this.txLoanAmount1);
            this.tabSalary.Controls.Add(this.txtBasicSalary);
            this.tabSalary.Controls.Add(this.txtBasicSalary1);
            this.tabSalary.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tabSalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabSalary.ForeColor = System.Drawing.Color.Black;
            this.tabSalary.Location = new System.Drawing.Point(4, 22);
            this.tabSalary.Name = "tabSalary";
            this.tabSalary.Padding = new System.Windows.Forms.Padding(3);
            this.tabSalary.Size = new System.Drawing.Size(848, 641);
            this.tabSalary.TabIndex = 1;
            this.tabSalary.Text = "Salary Details";
            this.tabSalary.UseVisualStyleBackColor = true;
            this.tabSalary.Click += new System.EventHandler(this.tabSalary_Click);
            this.tabSalary.MouseHover += new System.EventHandler(this.tabSalary_MouseHover);
            // 
            // lblMessage2
            // 
            this.lblMessage2.AutoSize = true;
            this.lblMessage2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage2.Location = new System.Drawing.Point(216, 30);
            this.lblMessage2.Name = "lblMessage2";
            this.lblMessage2.Size = new System.Drawing.Size(0, 20);
            this.lblMessage2.TabIndex = 23;
            // 
            // statusStrip2
            // 
            this.statusStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMessage2});
            this.statusStrip2.Location = new System.Drawing.Point(3, 616);
            this.statusStrip2.Name = "statusStrip2";
            this.statusStrip2.Size = new System.Drawing.Size(842, 22);
            this.statusStrip2.TabIndex = 22;
            // 
            // toolStripMessage2
            // 
            this.toolStripMessage2.Name = "toolStripMessage2";
            this.toolStripMessage2.Size = new System.Drawing.Size(0, 17);
            // 
            // btnEMI
            // 
            this.btnEMI.BackColor = System.Drawing.Color.ForestGreen;
            this.btnEMI.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEMI.ForeColor = System.Drawing.Color.White;
            this.btnEMI.Location = new System.Drawing.Point(654, 231);
            this.btnEMI.Name = "btnEMI";
            this.btnEMI.Size = new System.Drawing.Size(152, 38);
            this.btnEMI.TabIndex = 21;
            this.btnEMI.Text = "CALCULATE EMI";
            this.btnEMI.UseVisualStyleBackColor = false;
            this.btnEMI.Click += new System.EventHandler(this.btnEMI_Click);
            this.btnEMI.MouseHover += new System.EventHandler(this.btnEMI_MouseHover);
            // 
            // grpDetails
            // 
            this.grpDetails.Controls.Add(this.lblEMI);
            this.grpDetails.Controls.Add(this.label17);
            this.grpDetails.Controls.Add(this.lblTotal);
            this.grpDetails.Controls.Add(this.lblRateOfInterest);
            this.grpDetails.Controls.Add(this.lblTenure);
            this.grpDetails.Controls.Add(this.lblAmount);
            this.grpDetails.Controls.Add(this.label16);
            this.grpDetails.Controls.Add(this.label15);
            this.grpDetails.Controls.Add(this.label14);
            this.grpDetails.Controls.Add(this.label12);
            this.grpDetails.Controls.Add(this.lblGrossSalary);
            this.grpDetails.Controls.Add(this.lblDA);
            this.grpDetails.Controls.Add(this.label13);
            this.grpDetails.Controls.Add(this.label100);
            this.grpDetails.Controls.Add(this.lblBasicSalary);
            this.grpDetails.Controls.Add(this.label11);
            this.grpDetails.Controls.Add(this.lblID);
            this.grpDetails.Controls.Add(this.label10);
            this.grpDetails.Controls.Add(this.lblName);
            this.grpDetails.Controls.Add(this.label9);
            this.grpDetails.Location = new System.Drawing.Point(110, 291);
            this.grpDetails.Name = "grpDetails";
            this.grpDetails.Size = new System.Drawing.Size(477, 322);
            this.grpDetails.TabIndex = 20;
            this.grpDetails.TabStop = false;
            // 
            // lblEMI
            // 
            this.lblEMI.AutoSize = true;
            this.lblEMI.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEMI.Location = new System.Drawing.Point(194, 263);
            this.lblEMI.Name = "lblEMI";
            this.lblEMI.Size = new System.Drawing.Size(0, 16);
            this.lblEMI.TabIndex = 26;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(41, 263);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(34, 16);
            this.label17.TabIndex = 25;
            this.label17.Text = "EMI";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(194, 294);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(0, 13);
            this.lblTotal.TabIndex = 24;
            // 
            // lblRateOfInterest
            // 
            this.lblRateOfInterest.AutoSize = true;
            this.lblRateOfInterest.Location = new System.Drawing.Point(267, 232);
            this.lblRateOfInterest.Name = "lblRateOfInterest";
            this.lblRateOfInterest.Size = new System.Drawing.Size(0, 13);
            this.lblRateOfInterest.TabIndex = 23;
            // 
            // lblTenure
            // 
            this.lblTenure.AutoSize = true;
            this.lblTenure.Location = new System.Drawing.Point(194, 200);
            this.lblTenure.Name = "lblTenure";
            this.lblTenure.Size = new System.Drawing.Size(0, 13);
            this.lblTenure.TabIndex = 22;
            // 
            // lblAmount
            // 
            this.lblAmount.AutoSize = true;
            this.lblAmount.Location = new System.Drawing.Point(191, 163);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(0, 13);
            this.lblAmount.TabIndex = 21;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(41, 292);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(93, 16);
            this.label16.TabIndex = 20;
            this.label16.Text = "Total Salary";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(41, 232);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(203, 16);
            this.label15.TabIndex = 19;
            this.label15.Text = "Rate Of Interest (Per Annum)";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(41, 200);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(95, 16);
            this.label14.TabIndex = 18;
            this.label14.Text = "Loan Tenure";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(41, 163);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(97, 16);
            this.label12.TabIndex = 17;
            this.label12.Text = "Loan Amount";
            // 
            // lblGrossSalary
            // 
            this.lblGrossSalary.AutoSize = true;
            this.lblGrossSalary.Location = new System.Drawing.Point(194, 124);
            this.lblGrossSalary.Name = "lblGrossSalary";
            this.lblGrossSalary.Size = new System.Drawing.Size(0, 13);
            this.lblGrossSalary.TabIndex = 16;
            // 
            // lblDA
            // 
            this.lblDA.AutoSize = true;
            this.lblDA.Location = new System.Drawing.Point(188, 90);
            this.lblDA.Name = "lblDA";
            this.lblDA.Size = new System.Drawing.Size(0, 13);
            this.lblDA.TabIndex = 15;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(41, 124);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(98, 16);
            this.label13.TabIndex = 14;
            this.label13.Text = "Gross Salary";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label100.Location = new System.Drawing.Point(41, 90);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(29, 16);
            this.label100.TabIndex = 13;
            this.label100.Text = "DA";
            // 
            // lblBasicSalary
            // 
            this.lblBasicSalary.AutoSize = true;
            this.lblBasicSalary.Location = new System.Drawing.Point(191, 61);
            this.lblBasicSalary.Name = "lblBasicSalary";
            this.lblBasicSalary.Size = new System.Drawing.Size(0, 13);
            this.lblBasicSalary.TabIndex = 12;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(41, 61);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(96, 16);
            this.label11.TabIndex = 11;
            this.label11.Text = "Basic Salary";
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Location = new System.Drawing.Point(188, 14);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(0, 13);
            this.lblID.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(41, 16);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(90, 13);
            this.label10.TabIndex = 2;
            this.label10.Text = "EMPLOYEE ID";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(188, 38);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(0, 13);
            this.lblName.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(41, 38);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "NAME";
            // 
            // txtRateOfInterest
            // 
            this.txtRateOfInterest.Location = new System.Drawing.Point(321, 231);
            this.txtRateOfInterest.Name = "txtRateOfInterest";
            this.txtRateOfInterest.Size = new System.Drawing.Size(266, 20);
            this.txtRateOfInterest.TabIndex = 19;
            this.txtRateOfInterest.MouseHover += new System.EventHandler(this.txtRateOfInterest_MouseHover);
            // 
            // txtRateOfInterest1
            // 
            this.txtRateOfInterest1.AutoSize = true;
            this.txtRateOfInterest1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRateOfInterest1.Location = new System.Drawing.Point(107, 231);
            this.txtRateOfInterest1.Name = "txtRateOfInterest1";
            this.txtRateOfInterest1.Size = new System.Drawing.Size(203, 16);
            this.txtRateOfInterest1.TabIndex = 18;
            this.txtRateOfInterest1.Text = "Rate Of Interest (Per Annum)";
            // 
            // txtLoanTenure
            // 
            this.txtLoanTenure.Location = new System.Drawing.Point(298, 175);
            this.txtLoanTenure.Name = "txtLoanTenure";
            this.txtLoanTenure.Size = new System.Drawing.Size(266, 20);
            this.txtLoanTenure.TabIndex = 17;
            this.txtLoanTenure.MouseHover += new System.EventHandler(this.txtLoanTenure_MouseHover);
            // 
            // txLoanAmount
            // 
            this.txLoanAmount.Location = new System.Drawing.Point(298, 126);
            this.txLoanAmount.Name = "txLoanAmount";
            this.txLoanAmount.Size = new System.Drawing.Size(266, 20);
            this.txLoanAmount.TabIndex = 16;
            this.txLoanAmount.MouseHover += new System.EventHandler(this.txLoanAmount_MouseHover);
            // 
            // txtLoanTenure1
            // 
            this.txtLoanTenure1.AutoSize = true;
            this.txtLoanTenure1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLoanTenure1.Location = new System.Drawing.Point(107, 175);
            this.txtLoanTenure1.Name = "txtLoanTenure1";
            this.txtLoanTenure1.Size = new System.Drawing.Size(95, 16);
            this.txtLoanTenure1.TabIndex = 15;
            this.txtLoanTenure1.Text = "Loan Tenure";
            // 
            // txLoanAmount1
            // 
            this.txLoanAmount1.AutoSize = true;
            this.txLoanAmount1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txLoanAmount1.Location = new System.Drawing.Point(107, 126);
            this.txLoanAmount1.Name = "txLoanAmount1";
            this.txLoanAmount1.Size = new System.Drawing.Size(97, 16);
            this.txLoanAmount1.TabIndex = 14;
            this.txLoanAmount1.Text = "Loan Amount";
            // 
            // txtBasicSalary
            // 
            this.txtBasicSalary.Location = new System.Drawing.Point(298, 76);
            this.txtBasicSalary.Name = "txtBasicSalary";
            this.txtBasicSalary.Size = new System.Drawing.Size(266, 20);
            this.txtBasicSalary.TabIndex = 12;
            this.txtBasicSalary.MouseHover += new System.EventHandler(this.txtBasicSalary_MouseHover);
            // 
            // txtBasicSalary1
            // 
            this.txtBasicSalary1.AutoSize = true;
            this.txtBasicSalary1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBasicSalary1.Location = new System.Drawing.Point(107, 76);
            this.txtBasicSalary1.Name = "txtBasicSalary1";
            this.txtBasicSalary1.Size = new System.Drawing.Size(96, 16);
            this.txtBasicSalary1.TabIndex = 10;
            this.txtBasicSalary1.Text = "Basic Salary";
            // 
            // lblHeading
            // 
            this.lblHeading.AutoSize = true;
            this.lblHeading.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeading.ForeColor = System.Drawing.Color.Teal;
            this.lblHeading.Location = new System.Drawing.Point(257, 9);
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.Size = new System.Drawing.Size(367, 33);
            this.lblHeading.TabIndex = 1;
            this.lblHeading.Text = "Employee EMI Calculator";
            // 
            // EMICalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(900, 725);
            this.Controls.Add(this.lblHeading);
            this.Controls.Add(this.tabDetails);
            this.Name = "EMICalculator";
            this.Text = "EMICalculator";
            this.Load += new System.EventHandler(this.EMICalculator_Load);
            this.tabDetails.ResumeLayout(false);
            this.tabPersonal.ResumeLayout(false);
            this.tabPersonal.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.grpHobbies.ResumeLayout(false);
            this.grpHobbies.PerformLayout();
            this.grpGender.ResumeLayout(false);
            this.grpGender.PerformLayout();
            this.tabSalary.ResumeLayout(false);
            this.tabSalary.PerformLayout();
            this.statusStrip2.ResumeLayout(false);
            this.statusStrip2.PerformLayout();
            this.grpDetails.ResumeLayout(false);
            this.grpDetails.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabDetails;
        private System.Windows.Forms.TabPage tabPersonal;
        private System.Windows.Forms.TabPage tabSalary;
        private System.Windows.Forms.Label lblHeading;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbDept;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.GroupBox grpHobbies;
        private System.Windows.Forms.CheckBox chkOthers;
        private System.Windows.Forms.CheckBox chkPlaying;
        private System.Windows.Forms.CheckBox chkTravel;
        private System.Windows.Forms.CheckBox chkReading;
        private System.Windows.Forms.DateTimePicker dateDOB;
        private System.Windows.Forms.GroupBox grpGender;
        private System.Windows.Forms.RadioButton radioFemale;
        private System.Windows.Forms.RadioButton radioMale;
        private System.Windows.Forms.TextBox txtMobile;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Button btnView;
        private System.Windows.Forms.Label lblMessage1;
        private System.Windows.Forms.Button btnEMI;
        private System.Windows.Forms.TextBox txtRateOfInterest;
        private System.Windows.Forms.Label txtRateOfInterest1;
        private System.Windows.Forms.TextBox txtLoanTenure;
        private System.Windows.Forms.TextBox txLoanAmount;
        private System.Windows.Forms.Label txtLoanTenure1;
        private System.Windows.Forms.Label txLoanAmount1;
        private System.Windows.Forms.TextBox txtBasicSalary;
        private System.Windows.Forms.Label txtBasicSalary1;
        private System.Windows.Forms.GroupBox grpDetails;
        private System.Windows.Forms.Label lblGrossSalary;
        private System.Windows.Forms.Label lblDA;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label lblBasicSalary;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblEMI;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblRateOfInterest;
        private System.Windows.Forms.Label lblTenure;
        private System.Windows.Forms.Label lblAmount;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripMessage;
        private System.Windows.Forms.StatusStrip statusStrip2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripMessage2;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lblMessage2;
    }
}