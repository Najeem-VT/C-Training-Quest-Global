﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ModuleTest3
{
    public class Table
    {
        public void CreateTable(int n)      // Method to display multiplication table
        {
            lock (this)                     // Used for Thread Synchronization
            {
                Console.WriteLine("*** Multiplication Table of {0} ***",n);

                for (int index = 1; index <= 10; index++)
                {
                    Console.WriteLine("{0} * {1} = {2}", index, n, index * n);
                    Thread.Sleep(100);
                }
            }
           
        }
    }

    class GenerateTable
    {
        
        int n;
        Table t;
       public GenerateTable(int num)
        {
            this.n = num;          
        }

        public void Generate()
        {
            t = new Table();
            //lock (t)
            //{
                t.CreateTable(n);
            //}
           
        }

        public static void Main()
        {

            GenerateTable table1 = new GenerateTable(5);
            GenerateTable table2 = new GenerateTable(10);
            GenerateTable table3 = new GenerateTable(15);

            Thread thread1 = new Thread(new ThreadStart(table1.Generate));      // Thread 1
            //thread1.Name = "Thread1";
            thread1.Start();

            Thread thread2 = new Thread(new ThreadStart(table2.Generate));      // Thread 2
            //thread2.Name = "Thread2";
            thread2.Start(); 

            Thread thread3 = new Thread(new ThreadStart(table3.Generate));      // Thread 3
            //thread3.Name = "Thread3";
            thread3.Start();


            Console.ReadKey();
        }



    }

}
