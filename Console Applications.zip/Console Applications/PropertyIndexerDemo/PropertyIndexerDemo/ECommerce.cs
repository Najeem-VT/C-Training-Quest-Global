﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class ECommerce
{


    public static void Main(string[] args)
    {
        int option;
        do
        {
            Console.WriteLine("\n***** Welcome to E-Commerce ******\n");
            Console.WriteLine("\n\t Menu\n");
            Console.WriteLine("\n\t 1 => Add to Cart\n\t 2 => View Cart \n\t 3 => Checkout \n\t 4 => Add New Product\n\t 5 => Exit \n");

            option = Convert.ToInt32(Console.ReadLine());

            Product productObj = new Product();

            switch (option)
            {
                case 1:
                    productObj.AddToCart();
                    break;
                //case 2:
                //    productObj.ViewCart();
                //    break;
                //case 3:
                //    productObj.Checkout();
                //    break;
                case 4:
                    productObj.AddNewProduct();
                    break;
                case 5:
                    System.Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("\nInvalid Option Selected! Please Try Again.\n");
                    break;

            }

        } while (true);

        Console.ReadKey();
    }


}

class Product
{
    public Product[] items = new Product[100];
    public Product[] cart = new Product[5];

    public int productId;
    string productName;
    int price;
    string supplierName;

    static int count = 1;

    public Product()
    {
        productId = count;
        count++;
    }

    public string ProductName       // Property for productName attribute
    {
        get { return productName; }
        set { productName = value; }
    }

    public int Price                 // Property for price attribute
    {
        get { return price; }
        set { price = value; }
    }

    public string SupplierName        // Property for supplierName attribute
    {
        get { return supplierName; }
        set { supplierName = value; }
    }

    public void AddToCart()
    {
        int choice;

        Console.Write("\n***** Explore the Products ******\n");
        for (int i = 0; i < items.Length; i++)
        {

            Console.WriteLine("***********************************************");
            Console.Write("product id : " + items[i].productId + "\t");
            Console.Write("product Name : " + items[i].ProductName + "\t");
            Console.Write("Price : " + items[i].Price + "\t");
            Console.Write("Supplie rName : " + items[i].SupplierName + "\t");
            Console.WriteLine();
            Console.WriteLine("***********************************************");
        }
        Console.Write("Enter a Product ID to add to cart");
        choice = Convert.ToInt32(Console.ReadLine());






    }

    public void AddNewProduct()
    {
        int limit;
        Console.Write("Enter the No.of Items to Add");
        limit = Convert.ToInt32(Console.ReadLine());

        for (int i = 0; i < limit; i++)
        {
            items[i] = new Product();
            Console.WriteLine("***********************************************");
            Console.Write("\nEnter Product Name : ");
            items[i].ProductName = Console.ReadLine();
            Console.Write("\nEnter Price : ");
            items[i].Price = Convert.ToInt32(Console.ReadLine());
            Console.Write("\nEnter Supplier Name : ");
            items[i].SupplierName = Console.ReadLine();
            Console.WriteLine("***********************************************");
        }

    }
}