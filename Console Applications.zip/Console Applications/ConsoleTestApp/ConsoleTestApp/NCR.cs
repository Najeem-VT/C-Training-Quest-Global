﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class NCR
    {
        int n, r, result;

        public void ReadData()
        {
            Console.WriteLine("Enter The Value of N ");
            n = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter The Value of R ");
            r = Convert.ToInt32(Console.ReadLine());
        }

        public static int FindFactorial(int num)
        {
            int fact = 1;
            for (int i = 1; i <= num; i++)
            {

                fact *= i;
                
            }
            return fact;
        }

        public void FindNCR()
        {
            result = FindFactorial(n) / (FindFactorial(r) * FindFactorial(n - r));

        }

        public void DisplayResult()
        {
            Console.WriteLine("The Result is " + result);

        }


        public static void Main()
        {
            NCR obj1 = new NCR();
            obj1.ReadData();
            obj1.FindNCR();
            obj1.DisplayResult();
            Console.ReadKey();
        }

    }
}
