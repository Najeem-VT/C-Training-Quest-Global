﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class SingleDigitSum
    {
        int num, sum;

        public void ReadData()
        {
            Console.WriteLine("Enter Your Number ");
            num = Convert.ToInt32(Console.ReadLine());

        }

        public void FindSingleDigitSum()
        {
            int temp2 = num;
            do
            {
               sum= FindDigitSum(temp2);
                temp2 = sum;

            } while (temp2 > 9);
        }

        public int FindDigitSum(int n)
        {
            int digitSum=0;
            int temp = n;
            while (temp % 10 != 0)
            {
                int lastDigit = temp % 10;
                digitSum = digitSum + lastDigit;
                temp = temp / 10;
            }
            return digitSum;
        }

        public void DisplayResult()
        {
            Console.WriteLine("The Sum of Digit of {0} is {1}",num,sum);
           
        }


        public static void Main()
        {
            SingleDigitSum obj = new SingleDigitSum();
            obj.ReadData();
            obj.FindSingleDigitSum();
            obj.DisplayResult();
            Console.ReadKey();


        }
    }
}
