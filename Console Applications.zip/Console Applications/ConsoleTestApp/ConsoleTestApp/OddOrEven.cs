﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class OddOrEven
    {
        int number;
        String result;

        public void ReadNumber()
        {
            Console.WriteLine("Enter The Number ");
            number = Convert.ToInt32(Console.ReadLine());
        }

        public void CheckNumber()
        {
            if (number % 2 == 0)
            {
                result = "Even";
            }
            else
            {
                result = "Odd";
            }
        }
        public void DisplayResult()
        {
            Console.WriteLine("The Number is " + result);

        }


        public static void Main()
        {
            OddOrEven obj1 = new OddOrEven();
            obj1.ReadNumber();
            obj1.CheckNumber();
            obj1.DisplayResult();
            Console.ReadKey();
        }

    }
}
