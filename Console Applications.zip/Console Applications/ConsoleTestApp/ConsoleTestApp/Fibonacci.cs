﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Fibonacci
    {
        int limit;
        String fib;

        public void ReadLimit()
        {
            Console.WriteLine("Enter The Limit ");
            limit = Convert.ToInt32(Console.ReadLine());

        }

        public void FindFibonacci()
        {
            int n1 = 0, n2 = 1, n3;
            fib = n1 + " " + n2;
            for (int i = 2; i < limit; i++)
            {
                n3 = n1 + n2;
                fib += " " + n3;
                n1 = n2;
                n2 = n3;
            }

        }

        public void DisplayResult()
        {
            Console.WriteLine("The Fibonacci Series : " +fib);

        }


        public static void Main()
        {
            Fibonacci obj1 = new Fibonacci();
            obj1.ReadLimit();
            obj1.FindFibonacci();
            obj1.DisplayResult();
            Console.ReadKey();
        }

    }
}
