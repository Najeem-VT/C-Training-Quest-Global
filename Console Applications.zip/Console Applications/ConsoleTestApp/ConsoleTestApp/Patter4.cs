﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Patter4
    {
        public static void Main()
        {
            Console.WriteLine("Enter a Number");
            int num = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Pattern\n");

            for (int i = 1; i <= num; i++)
            {
                for (int j = 1; j <= num-i; j++)
                {
                    Console.Write(" ");
                }
                for (int k = 1; k <= i; k=k+3)
                {
                    Console.Write("*");
                }
                for (int j = 1; j <= num - i; j++)
                {
                    Console.Write(" ");
                }
                Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
