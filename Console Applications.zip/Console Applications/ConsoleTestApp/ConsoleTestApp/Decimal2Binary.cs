﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Decimal2Binary
    {
        int deci;
        String bin = "";

        public void ReadDecimal()
        {
            Console.WriteLine("Enter The Decimal Number ");
            deci = Convert.ToInt32(Console.ReadLine());

        }

        public void FindBinary()
        {
            int num = deci;
            while (num >0)
            {
                int remainder = num % 2;
                bin =bin+remainder.ToString();
                num = num / 2;
            }
        }

        public void DisplayResult()
        {
            Console.WriteLine("The Binary is " + bin);

        }


        public static void Main()
        {
            Decimal2Binary obj1 = new Decimal2Binary();
            obj1.ReadDecimal();
            obj1.FindBinary();
            obj1.DisplayResult();
            Console.ReadKey();
        }
    }
}
