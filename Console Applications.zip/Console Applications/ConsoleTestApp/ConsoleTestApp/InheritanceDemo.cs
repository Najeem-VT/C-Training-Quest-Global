﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class InheritanceDemo
    {

    }

    class PersonInheritance
    {
        int id;
        String name;

        public void ReadPerson()
        {
            Console.WriteLine("Enter The Id ");
            id = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter The Name ");
            name = Console.ReadLine();
        }

        public void DisplayPerson()
        {
            Console.WriteLine("ID : {0}");
           
        }
    }
}
