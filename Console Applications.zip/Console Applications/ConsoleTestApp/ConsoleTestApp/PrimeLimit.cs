﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class PrimeLimit
    {
        public int limit;

       public PrimeLimit(int limit)
        {
            this.limit = limit;
        }

        public void DisplayPrime()
        {
            Console.WriteLine("The Prime Numbers are:-");
            for (int no = 2; no < limit; no++)
            {
                if (CheckPrime(no))
                {
                    Console.WriteLine(no);
                }
               
            }
        }

        public bool CheckPrime(int num)
        {
            bool flag = true;
            for (int no = 2; no < num; no++)
            {
                if (num % no == 0)
                {
                    flag = false;
                    break;
                }
            }

            if (flag)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static void Main()
        {
            PrimeLimit p1 = new PrimeLimit(10);
            p1.DisplayPrime();
            Console.ReadKey();
        }
    }
}
