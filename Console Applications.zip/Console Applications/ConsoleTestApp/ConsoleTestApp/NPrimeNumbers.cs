﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class NPrimeNumbers
    {
        int limit;

        public void ReadLimit()
        {
            Console.WriteLine("Enter The Limit ");
            limit=Convert.ToInt32(Console.ReadLine());
        }

        public void DisplayPrime()
        {
            Console.WriteLine("Prime Numbers");

            int count = 1;
         
                for (int num = 1; num > 0; num++)
                {
                    bool flag = true;
                    for (int no = 2; no < num; no++)
                    {
                        if (num % no == 0)
                        {
                            flag = false;
                            break;
                        }
                    }

                    if (flag)
                    {
                        
                        Console.WriteLine(num);
                        count++;
                        if (count>limit)
                        {
                            break;
                        }
                    }
                 }
         }

   
        public static void Main()
        {
            NPrimeNumbers obj1 = new NPrimeNumbers();
            obj1.ReadLimit();
            obj1.DisplayPrime();
            Console.ReadKey();
        }

    }
}
