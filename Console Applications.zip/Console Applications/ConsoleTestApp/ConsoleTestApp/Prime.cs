﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Prime
    {
        int num;
        String result;

        public void ReadNumber()
        {
            Console.WriteLine("Enter The Number ");
            num = Convert.ToInt32(Console.ReadLine());

        }

        public void CheckPrime()
        {
            if (num == 1)
            {
                result = "NOT SUITABLE FOR THIS CALCULATION";
            }
            else
            {
                bool flag = true;
                for (int no = 2; no < num; no++)
                {
                    if (num % no == 0)
                    {
                        flag = false;
                        break;
                    }
                }

                if (flag)
                {
                    result = "Prime";
                }
                else
                {
                    result = "Not Prime";
                }
            }
           

        }

        public void DisplayResult()
        {
            Console.WriteLine("The Number {0} is {1}",num,result);
          
        }


        public static void Main()
        {
            Prime obj1 = new Prime();
            obj1.ReadNumber();
            obj1.CheckPrime();
            obj1.DisplayResult();
            Console.ReadKey();
        }

    }
}
