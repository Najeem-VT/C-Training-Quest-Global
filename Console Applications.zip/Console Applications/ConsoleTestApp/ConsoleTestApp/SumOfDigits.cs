﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class SumOfDigits
    {
        int num, digitSum = 0;

        public SumOfDigits()
        {
            
        }

        public SumOfDigits(int num)
        {
            this.num = num;
        }
        
        public void ReadNumber()
        {
            Console.WriteLine("Enter The Number ");
            num = Convert.ToInt32(Console.ReadLine());

        }

        public void FindSum()
        {
            int temp = num;
            while(temp%10!=0)
            {
                int lastDigit = temp % 10;
                digitSum = digitSum + lastDigit;
                temp = temp / 10;
            }

        }

        public void DisplayResult()
        {
            Console.WriteLine("The Sum of Digits of " + num + " is " + digitSum);

        }


        public static void Main()
        {
            SumOfDigits obj1 = new SumOfDigits();
            obj1.ReadNumber();
            obj1.FindSum();
            obj1.DisplayResult();
            Console.ReadKey();

            /*
            SumOfDigits obj2 = new SumOfDigits(255);
            obj1.FindSum();
            obj1.DisplayResult();
            Console.ReadKey();
            */
        }

    }
}
