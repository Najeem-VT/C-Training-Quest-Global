﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class FibonacciRecursion
    {
        int limit;
        string fib;

        public FibonacciRecursion(int limit)
        {
            this.limit = limit;
        }

        public void FindFibonacci(int n1,int n2)
        {
            int n3;
            n3 = n1 + n2;
            n1 = n2;
            n2 = n3;
            fib = fib + " " + n3;
            limit--;
            if (limit > 0)
            {
                FindFibonacci(n1, n2);
            }
          
        }

        public void DisplayResult()
        {
            Console.WriteLine("The Fibonacci Series : " + fib);

        }

        public static void Main()
        {
            int n1 = 0, n2 = 1;
            FibonacciRecursion obj = new FibonacciRecursion(5);
            obj.FindFibonacci(n1, n2);
            obj.DisplayResult();
            Console.ReadKey();


        }
    }
}
