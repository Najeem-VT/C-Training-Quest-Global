﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Interest
    {
        double principle, interest;
        static double rateOfInterest=0.05;
        int term;


        public void ReadData()
        {
            Console.WriteLine("Enter Principle Amount : ");
            principle = Convert.ToDouble(Console.ReadLine());


            
        }

        public void CheckInterest()
        {
            int typeOfInterest;
            Console.WriteLine("Enter An Interest Type : (1) => Simple Interest , (2) => Compound Interest");
            typeOfInterest = Convert.ToInt32(Console.ReadLine());

            switch (typeOfInterest)
            {
                case 1:
                    SimpleInterest();
                    break;
                case 2:
                    CompoundInterest();
                    break;
                default:
                    Console.WriteLine("Please Provide a Valid Input\n");
                    break;
            }
        }

        public void SimpleInterest()
        {
            Console.WriteLine("Enter the Term of the Plan: ");
            term = Convert.ToInt32(Console.ReadLine());

            interest = principle * term * rateOfInterest;
        }

        public void CompoundInterest()
        {
            Console.WriteLine("Enter the Compounding Periods: ");
            term = Convert.ToInt32(Console.ReadLine());

            interest = (principle * Math.Pow(1 + rateOfInterest, term)) - principle;
        }

        public void Display()
        {
            Console.WriteLine("Interest : "+interest);
        }
        public static void Main()
        {
            Interest obj1 = new Interest();
            obj1.ReadData();
            obj1.CheckInterest();
            obj1.Display();
            Console.ReadKey();
        }
    }
}


