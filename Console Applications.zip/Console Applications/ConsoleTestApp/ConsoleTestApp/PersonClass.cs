﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class PersonClass
    {
        public int id;
        public string name;

        public void ReadPerson()
        {
            Console.Write("Enter ID :");
            id = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Name :");
            name = Console.ReadLine();
        }

        public void DisplayPerson()
        {
            Console.WriteLine("Enter ID : "+id);
            Console.WriteLine("Enter Name :"+name);
        }

        public static void Main()
        {
            StudentClass stud1 = new StudentClass();
            stud1.ReadStudent();
            stud1.FindResult();
            stud1.DisplayStudent();
            Console.ReadKey();

        }
    }

    class StudentClass:PersonClass
    {
        int mark1, mark2, mark3, total;
        string result;
        static int passMark = 50;
      
        public void ReadStudent()
        {
            ReadPerson();

            Console.Write("Enter Mark 1 :");
            mark1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Mark 2 :");
            mark2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Mark 3 :");
            mark3 = Convert.ToInt32(Console.ReadLine());

        }

        public void FindResult()
        {
            total = mark1 + mark2 + mark3;
            if (total >= passMark)
            {
                result = "Passed!";
            }
            else
            {
                result = "Failed!";
            }
        }

        public void DisplayStudent()
        {
            DisplayPerson();
            Console.WriteLine("MARK 1 : " + mark1);
            Console.WriteLine("MARK 2 :" + mark2);
            Console.WriteLine("MARK 3 :" + mark3);
            Console.WriteLine("*************************\n");

            Console.WriteLine("Result : " + result);
        }
    }
}
