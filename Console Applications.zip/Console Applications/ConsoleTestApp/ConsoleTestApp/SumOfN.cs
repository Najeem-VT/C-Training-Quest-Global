﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class SumOfN
    {
        int limit, sum = 0, num;

        public void ReadLimit()
        {
            Console.WriteLine("Enter The Limit ");
            limit = Convert.ToInt32(Console.ReadLine());

        }

        public void FindSum()
        {
            for(int i=1;i<=limit;i++)
            {
                Console.WriteLine("Enter a Number");
                num = Convert.ToInt32(Console.ReadLine());
                if(num%2==0)
                {
                    sum += num;
                }
            }

        }

        public void DisplayResult()
        {
            Console.WriteLine("The Sum is " + sum);

        }

        public static void Main()
        {
            SumOfN obj1 = new SumOfN();
            obj1.ReadLimit();
            obj1.FindSum();
            obj1.DisplayResult();
            Console.ReadKey();
        }

    }
}
