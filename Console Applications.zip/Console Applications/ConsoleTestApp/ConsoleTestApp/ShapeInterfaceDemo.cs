﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
   public class ShapeInterfaceDemo
    {
       public double area;
       public static double Pi= 3.14;
        public static void Main()
        {
            CircleClass c1 = new CircleClass(3.15);
            c1.DisplayArea();

            TriangleClass t1 = new TriangleClass(2, 5);
            t1.DisplayArea();

            SquareClass s1 = new SquareClass(3);
            s1.DisplayArea();

            Console.ReadKey();

        }
    }

    interface ShapeInterface
    {
        void DisplayArea();
    }

    public class CircleClass : ShapeInterfaceDemo,ShapeInterface
    {
        double radius;
       public CircleClass(double radius)
        {
            this.radius = radius;
        }

    
        public void DisplayArea()
        {
            area = Pi * radius * radius;
            Console.WriteLine("Area of Circle : {0}", area);
        }

    }

   public class TriangleClass : ShapeInterfaceDemo, ShapeInterface
    {
        double @base, height;

        public TriangleClass(int @base, int height)
        {
            this.@base = @base;
            this.height = height;
        }


        public void DisplayArea()
        {
            area = 0.5 * @base * height;
            Console.WriteLine("Area of Triangle : {0}", area);
        }

    }


    public class SquareClass : ShapeInterfaceDemo, ShapeInterface
    {
        double sideLength;

        public SquareClass(int sideLength)
        {
            this.sideLength = sideLength;
        }


        public void DisplayArea()
        {
            area = sideLength * sideLength;
            Console.WriteLine("Area of Square : {0}", area);
        }

    }

}
