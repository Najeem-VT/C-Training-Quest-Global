﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class FactorialRecursion
    {
        int fact = 1;
     
        public int FindFactorial(int n)
        {
            if (n == 1)
            {
                return 1;
                
            }
            else
            {
                
                   return fact*FindFactorial(n-1);
                
            }
        }

        public void DisplayResult()
        {
            Console.WriteLine("The Factorial is {0}",fact);

        }

        public static void Main()
        {
            FactorialRecursion f1 = new FactorialRecursion();
           f1.FindFactorial(5);
            Console.ReadKey();
        }
    }
}
