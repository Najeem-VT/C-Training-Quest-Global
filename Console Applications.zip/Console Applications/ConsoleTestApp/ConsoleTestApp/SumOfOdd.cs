﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class SumOfOdd
    {
        int limit, sum = 0;

        public void ReadLimit()
        {
            Console.WriteLine("Enter The Limit ");
            limit = Convert.ToInt32(Console.ReadLine());

        }

        public void FindSum()
        {
            int count = 1;
            for (int i = 1; i >0; i++)
            {
               
                if (i % 2 == 1)
                {
                    sum += i;
                    count++;
                }

                if (count > limit)
                {
                    break;
                }
            }

        }

        public void DisplayResult()
        {
            Console.WriteLine("The Sum of {0} Odd Numbers: {1}",limit,sum);

        }

        public static void Main()
        {
            SumOfOdd obj1 = new SumOfOdd();
            obj1.ReadLimit();
            obj1.FindSum();
            obj1.DisplayResult();
            Console.ReadKey();
        }

    }
}
