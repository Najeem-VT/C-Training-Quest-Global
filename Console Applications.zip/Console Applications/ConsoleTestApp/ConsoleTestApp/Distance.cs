﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Distance
    {
        int feet, inches;

       

        public void ReadData()
        {
            Console.WriteLine("Enter The Feet ");
            feet = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter The Inches ");
            inches = Convert.ToInt32(Console.ReadLine());

        }

        public void AddDistance(Distance dist1,Distance dist2)
        {
            feet = dist1.feet + dist2.feet;
            inches = dist1.inches + dist2.inches;

            if (inches >= 12)
            {
                feet++;
                inches %= 12;
            }
        }

        public Distance AddDistance(Distance dist2)
        {
            Distance d1 = new Distance();
            d1.feet = feet + dist2.feet;
            d1.inches = inches + dist2.inches;

            if (d1.inches >= 12)
            {
                d1.feet++;
                d1.inches %= 12;
            }

            return d1;
        }

        public static Distance operator +(Distance dist1, Distance dist2)
        {
        
            Distance d2 = new Distance();
            d2.feet = dist1.feet + dist2.feet;
            d2.inches = dist1.inches + dist2.inches;

            if (d2.inches >= 12)
            {
                d2.feet++;
                d2.inches %= 12;
            }

            return d2;
        }

        public void SubtractDistance(Distance dist1, Distance dist2)
        {
            int d1, d2, d3;

          
            d1 = (dist1.feet *12) + dist1.inches;

            d2 = (dist2.feet*12) + dist2.inches;

            d3 = Math.Abs(d1 - d2);
            
            feet = d3 / 12;
            inches = d3 % 12;
        }

        public Distance SubtractDistance(Distance dist2)
        {

            int d1, d2, d3;
            Distance distance1 = new Distance();

            d1 = (feet *12)+ inches;

            d2 = (dist2.feet*12) + dist2.inches;

            d3 = Math.Abs(d1-d2);

            distance1.feet = d3 / 12;
            distance1.inches = d3 % 12;

            return distance1;
        }

        public static Distance operator -(Distance dist1, Distance dist2)
        {
            Distance distance2 = new Distance();

            int d1, d2, d3;

            dist1.feet *= 12;
            d1 = dist1.feet + dist1.inches;

            dist2.feet *= 12;
            d2 = dist2.feet + dist2.inches;

            d3 = Math.Abs(d1 - d2);

            distance2.feet = d3 / 12;
            distance2.inches = d3 % 12;

            return distance2;
        }


        public void DisplayResult()
        {
            Console.WriteLine("{0} Feet , {1} Inches  ",feet,inches);

        }

        public static void Main()
        {

            Console.WriteLine("********** Enter The First Distance ***************");
            Distance dist1 = new Distance();
            dist1.ReadData();
            Console.WriteLine("********** Enter The Second Distance ***************");
            Distance dist2 = new Distance();
            dist2.ReadData();

            Console.WriteLine("********** Sum of the Distances 1***************");
            Distance dist3 = new Distance();
            dist3.AddDistance(dist1, dist2);
            dist3.DisplayResult();

            Console.WriteLine("********** Sum of the Distances 2 ***************");
            Distance  dist4 = dist1.AddDistance(dist2);
            dist4.DisplayResult();

            Console.WriteLine("********** Sum of the Distances Using Operator Precedence ***************");
            Distance dist5 = dist1 + dist2;
            dist5.DisplayResult();

            Console.WriteLine("********** Difference Between the Distances 1***************");
            Distance dist6 = new Distance();
            dist6.SubtractDistance(dist1, dist2);
            dist6.DisplayResult();

            Console.WriteLine("********** Difference Between the Distances 2 ***************");
            Distance dist7 = dist1.SubtractDistance(dist2);
            dist7.DisplayResult();

            Console.WriteLine("********** Difference Between the Distances Using Operator Precedence ***************");
            Distance dist8 = dist1 - dist2;
            dist8.DisplayResult();
            Console.ReadKey();
        }

    }
}