﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class NumberReverse
    {
        int num, reverse=0;

        public void ReadString()
        {
            Console.WriteLine("Enter The Number ");
            num = Convert.ToInt32(Console.ReadLine());

        }

        public void FindReverse()
        {
            int temp = num;
            while (temp > 0)
            {
                reverse = reverse * 10;
                reverse = reverse + temp % 10;
                temp = temp / 10;
            }

        }

        public void DisplayResult()
        {
            Console.WriteLine("The Reverse of {0} is {1}",num,reverse);
        }


        public static void Main(String[] args)
        {
            NumberReverse obj1 = new NumberReverse();
            obj1.ReadString();
            obj1.FindReverse();
            obj1.DisplayResult();
            Console.ReadKey();
        }


    }
}
