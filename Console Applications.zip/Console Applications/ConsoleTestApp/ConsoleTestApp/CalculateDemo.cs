﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class CalculateDemo
    {
        public static void Main()
        {
            Console.WriteLine("Sum of {0} and {1} is {2}", 2, 4, Calculate.Sum(2, 4));

            Calculate obj = new Calculate();
            Console.WriteLine("Difference between {0} and {1} is {2}", 9, 4, obj.Difference(9, 4));

            Console.ReadKey();
        }
    }
}
