﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Abstraction
    {
        public static void Main()
        {
            XYZ xyz = new XYZ();
            xyz.print();
            xyz.Show();
            XYZ.Display();
            xyz.Print();

            Console.ReadKey();

        }
    }

   abstract class ABC
    {
        int val1, val2;

        public void print()
        {
            Console.WriteLine("I am in Print Method.");
        }

        public static void Display()
        {
            Console.WriteLine("I am in Display Method.");
        }

        public abstract void Show();
        
    }

    class XYZ : ABC
    {
        public override void Show()
        {
            Console.WriteLine("I am in Show Method.");
        }

        public  void Print()
        {
            Console.WriteLine("I am in Print Method.");
        }
    }


}
