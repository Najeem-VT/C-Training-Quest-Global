﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Menu
    {
        public static void Main()
        {

            do
            {


                Console.WriteLine("*********************************************");
                Console.WriteLine("----Options----");
                Console.WriteLine("1 : DIGIT SUM ");
                Console.WriteLine("2 : PRIME OR NOT ");
                Console.WriteLine("3 : EXIT");
                Console.WriteLine("*********************************************");
                Console.WriteLine("*********************************************");
                Console.WriteLine("Please Enter an Option");
                int option = Convert.ToInt32(Console.ReadLine());
                switch (option)
                {
                    case 1:
                        SumOfDigits obj1 = new SumOfDigits();
                        obj1.ReadNumber();
                        obj1.FindSum();
                        obj1.DisplayResult();
                        break;
                    case 2:
                        Prime obj2 = new Prime();
                        obj2.ReadNumber();
                        obj2.CheckPrime();
                        obj2.DisplayResult();
                        break;
                    case 3:
                        System.Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Please Provide a Valid Input!");
                        break;


                }
            } while (true);
        }
    }
}
