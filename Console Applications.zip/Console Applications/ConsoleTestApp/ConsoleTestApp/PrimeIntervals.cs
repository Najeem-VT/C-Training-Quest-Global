﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class PrimeIntervals
    {
        int interval1, interval2;

        public void ReadIntervals()
        {
            Console.WriteLine("Enter The First Number ");
            interval1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter The Second Number ");
            interval2 = Convert.ToInt32(Console.ReadLine());
        }

        public void DisplayPrime()
        {
            Console.WriteLine("Prime Number between "+interval1+" and "+interval2);

            for (int num = interval1; num <= interval2; num++)
            {
               bool flag = true;
                for (int no = 2; no < num; no++)
                {
                    if (num % no == 0)
                    {
                        flag = false;
                        break;
                    }
                }

                if (flag)
                {
                    Console.WriteLine(num);
                }
             

            }
            

        }

        public static void Main()
        {
            PrimeIntervals obj1 = new PrimeIntervals();
            obj1.ReadIntervals();
            obj1.DisplayPrime();
            Console.ReadKey();
        }

    }


}
