﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class PerfectNumber
    {
        int num;
        string result;

        public void ReadData()
        {
            Console.WriteLine("Enter a Number");
            num = Convert.ToInt32(Console.ReadLine());
        }

        public void CheckPerfect()
        {
            if (SumDivisors(num) == num)
            {
                result = "Perfect";
            }
            else
            {
                result = "Not Perfect";
            }
        }

        public static int SumDivisors(int n)
        {
            int sum = 0;

            for(int i = 1; i < n; i++)
            {
                if (n%i==0)
                {
                    sum = sum + i;
                }
            }

            return sum;
           
        }

        private void DisplayResult()
        {
            Console.WriteLine("The Number {0} is {1}", num, result);
        }


        public static void Main()
        {
            PerfectNumber obj = new PerfectNumber();
            obj.ReadData();
            obj.CheckPerfect();
            obj.DisplayResult();
            Console.ReadKey();
        }


    }
}
