﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Armstrong
    {
        int num;
        String result;

        public void ReadNumber()
        {
            Console.WriteLine("Enter The Number ");
            num = Convert.ToInt32(Console.ReadLine());

        }

        public void CheckAngstrom()
        {
            int temp = num;
            double digitSum = 0;
            int noDigits = temp.ToString().Length;
            while (temp % 10 != 0)
            {
                int lastDigit = temp % 10;
                digitSum = digitSum + Math.Pow(lastDigit,noDigits);
                temp = temp / 10;
            }

            if (digitSum == num)
            {
                result = "Armstrong";
            }
            else
            {
                result = "Not Armstrong";
            }

        }

        public void DisplayResult()
        {
            Console.WriteLine("The Number {0} is {1}", num, result);

        }


        public static void Main()
        {
            Armstrong obj1 = new Armstrong();
            obj1.ReadNumber();
            obj1.CheckAngstrom();
            obj1.DisplayResult();
            Console.ReadKey();
        }
    }
}
