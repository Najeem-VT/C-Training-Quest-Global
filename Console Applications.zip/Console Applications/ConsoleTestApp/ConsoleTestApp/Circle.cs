﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Circle
    {
        double radius, area, circumference;

        public void ReadRadius()
        {
            Console.WriteLine("Enter The Radius of the circle ");
            radius = Convert.ToInt32(Console.ReadLine());

        }

        public void FindArea()
        {
            area = Math.PI*Math.Pow(radius,2);
        }

        public void FindCircumference()
        {
            circumference = 2 * Math.PI * radius;
        }

        public void DisplayResult()
        {
            Console.WriteLine("The Area of the Circle : " + area);
            Console.WriteLine("The Circumference of the Circle : " + circumference);
        }


        public static void Main()
        {
            Circle obj1 = new Circle();
            obj1.ReadRadius();
            obj1.FindArea();
            obj1.FindCircumference();
            obj1.DisplayResult();
            Console.ReadKey();
        }

    }
}
