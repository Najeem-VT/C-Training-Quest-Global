﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class InterfaceDemo1
    {
        public static void Main()
        {
            Sub1 obj1 = new Sub1();
            obj1.Display();
            Console.ReadKey();
        }
    }

   public class Base1
    {
        public void Display()
        {
            Console.WriteLine("I am in BASE 1.");
        }
    }

    interface Inter1
    {
        void Display();
    }

    public class Sub1 : Base1,Inter1
    {
        public new void Display()
        {
            Console.WriteLine("I am in BASE 1.");
        }
    }
}
