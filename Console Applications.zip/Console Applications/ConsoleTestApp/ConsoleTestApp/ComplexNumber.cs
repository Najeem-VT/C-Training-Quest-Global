﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class ComplexNumber
    {
        int real, imaginary;

        public void ReadData()
        {
            Console.Write("Enter Real Part :");
            real = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Imaginary Part :");
            imaginary = Convert.ToInt32(Console.ReadLine());
        }

        public static ComplexNumber operator +(ComplexNumber c1, ComplexNumber c2)
        {
            ComplexNumber c3 = new ComplexNumber();

            c3.real = c1.real + c2.real;
            c3.imaginary = c1.imaginary + c2.imaginary;
            return c3;
        }

        public static ComplexNumber operator -(ComplexNumber c1, ComplexNumber c2)
        {
            ComplexNumber c3 = new ComplexNumber();

            c3.real = c1.real - c2.real;
            c3.imaginary = c1.imaginary - c2.imaginary;
            return c3;
        }

        public void Display()
        {
            if (imaginary < -1)
            {
                Console.WriteLine(" is : {0}{1}i ", real, imaginary);
            }
            else
            {
                Console.WriteLine(" is : {0}+{1}i ", real, imaginary);
            }
            

        }


        public static void Main()
        {


            Console.WriteLine(" ****** Enter First Number  ******");

            ComplexNumber c1 = new ComplexNumber();
            c1.ReadData();

            Console.WriteLine(" ****** Enter Second Number  ******");

            ComplexNumber c2 = new ComplexNumber();
            c2.ReadData();

            ComplexNumber c3 = c1 + c2;
            ComplexNumber c4 = c1 - c2;

            Console.Write("Sum is ");
            c3.Display();

            Console.Write("Difference is ");
            c4.Display();

            Console.ReadKey();

        }
        }
    }
