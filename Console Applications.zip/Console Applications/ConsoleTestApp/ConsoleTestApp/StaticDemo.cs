﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class StaticDemo
    {
        int i = 10;
        static int j = 30;

        public void Inc()
        {
            Console.WriteLine("i:{0} j:{1}",i,j);
            i++;
            j++;
        }

        public static void Main()
        {
            StaticDemo s1 = new StaticDemo();
            StaticDemo s2 = new StaticDemo();
            StaticDemo s3 = new StaticDemo();
            StaticDemo s4 = new StaticDemo();

            s1.Inc();
            s2.Inc();
            s3.Inc();           
            s4.Inc();


            Console.ReadKey();
        }
    }
}
