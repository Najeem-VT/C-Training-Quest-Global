﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Binary2Decimal
    {
        int bin, deci=0;

        public void ReadBinary()
        {
            Console.WriteLine("Enter The Binary Number");
            bin = Convert.ToInt32(Console.ReadLine());

        }

        public void FindDecimal()
        {
            int index = 0;
            int num = bin;
            while (num > 0) 
            {
                int lastDigit = num % 10;
                deci = deci + (lastDigit * (int)Math.Pow(2, index));
                num = num / 10;
                index++;
            }
        }

        public void DisplayResult()
        {
            Console.WriteLine("The Deciaml is " + deci);

        }


        public static void Main()
        {
            Binary2Decimal obj1 = new Binary2Decimal();
            obj1.ReadBinary();
            obj1.FindDecimal();
            obj1.DisplayResult();
            Console.ReadKey();
        }

    }
}
