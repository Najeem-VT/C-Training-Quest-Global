﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class InheritanceDemo1
    {
        public static void Main()
        {
            A a1 = new A();
            B b1 = new B();

            a1.displayA();
            b1.displayB();
            b1.displayA();
            b1.display();

            Console.ReadKey();
        }
    }

    class A
    {
        public int val1;

        public A()
        {
            val1 = 10;
        }
        public A(int n)
        {
            val1 = n;
        }

        public void displayA()
        {
            Console.WriteLine("IAM IN BASE CLASS A VAL1=" + val1);
        }
        public virtual void display()
        {
            Console.WriteLine("Display in A");
        }
    }

    class B : A
    {
        public int val2;

        public B()
        {
            val2 = 100;
        }
        public B(int v1,int v2):base(v1)
        {
            val2 = 100;
        }

        public void displayB()
        {
            Console.WriteLine("IAM IN CHILD CLASS B VAL1=" + val1);
            Console.WriteLine("IAM IN CHILD CLASS B VAL2=" + val2);
        }

        public override void display()
        {
            base.display();
            Console.WriteLine("Display in B");
        }
    }
}
