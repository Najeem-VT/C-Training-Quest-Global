﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    abstract class Shape
    {
        public const double Pi = 3.14;
        public  double area;

        public abstract void FindArea();


        public void DisplayArea()
        {
            Console.Write("Area = {0} units^2" +
                "",area);
        }

        public static void Main()
        {
            Console.WriteLine("**************  CIRCLE ****************");
            CircleShape c1 = new CircleShape();
            c1.ReadData();
            c1.FindArea();
            c1.DisplayArea();

            Console.WriteLine("**************  TRIANGLE ****************");
            TriangleShape t1 = new TriangleShape();
            t1.ReadData();
            t1.FindArea();
            t1.DisplayArea();

            Console.WriteLine("**************  SQUARE ****************");
            SquareShape s1 = new SquareShape();
            s1.ReadData();
            s1.FindArea();
            s1.DisplayArea();

            Console.ReadKey();
        }

    }

    class CircleShape : Shape
    {
        double radius;
        public void ReadData()
        {
            Console.Write("Enter the Radius of the Circle :");
            radius = Convert.ToDouble(Console.ReadLine());
        }
        public override void FindArea()
        {
            area = Pi * Math.Pow(radius, 2);
        }
    }

    class TriangleShape : Shape
    {
        double height,@base;
        public void ReadData()
        {
            Console.Write("Enter the Height of the Triangle :");
            height = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter the Base of the Triangle :");
            @base = Convert.ToDouble(Console.ReadLine());
        }
        public override void FindArea()
        {
            area = 0.5 * @base * height;
        }
    }

    class SquareShape : Shape
    {
        double sideLength;
        public void ReadData()
        {
            Console.Write("Enter the Length of the Side of Square :");
            sideLength = Convert.ToDouble(Console.ReadLine());
        }
        public override void FindArea()
        {
            area = sideLength* sideLength;
        }
    }

  
}
