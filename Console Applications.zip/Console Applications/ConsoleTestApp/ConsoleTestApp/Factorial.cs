﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Factorial
    {
        int num, fact = 1;

        public void ReadNumber()
        {
            Console.WriteLine("Enter The Number ");
            num = Convert.ToInt32(Console.ReadLine());

        }

        public void FindFactorial()
        {
            for (int i = 1; i <= num; i++)
            {

                fact *= i;
            }

        }

        public void DisplayResult()
        {
            Console.WriteLine("The Fctorial of "+num+" is " + fact);

        }


        public static void Main()
        {
            Factorial obj1 = new Factorial();
            obj1.ReadNumber();
            obj1.FindFactorial();
            obj1.DisplayResult();
            Console.ReadKey();
        }

    }
}
