﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class ShapeOverloading
    {
        double area;
        const double Pi = 3.14;

        // To find Area of Circle
        public void Display(double radius)      
        {
            area = Pi * radius * radius;
            Console.WriteLine("Area of Circle : {0}",area);

        }
        // To find Area of Triangle
        public void Display(int @base,int height)
        {
            area = 0.5 * @base * height;
            Console.WriteLine("Area of Triangle : {0}", area);
        }
        //  To find Area of Square
        public void Display(int sideLength)
        {
            area = sideLength * sideLength;
            Console.WriteLine("Area of Square : {0}", area);
        }

        public static void Main()
        {
            ShapeOverloading shape = new ShapeOverloading();
            shape.Display(2);   // Area of Square
            shape.Display(2,3); // Area of Triangle
            shape.Display(2.5); // Area of Circle
            Console.ReadKey();
        }
    }
}
