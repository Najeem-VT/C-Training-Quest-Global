﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Student
    {

        int id, mark, total;
        String name, result;
        static int minMark = 0, maxMark = 100, passMark = 40;

        public void ReadData()
        {
           
            Console.Write("ID : ");
            id = Convert.ToInt32(Console.ReadLine());

            Console.Write("NAME : ");
            name = Console.ReadLine();
        }
        public int ReadMarks()
        {
            bool flag = true;
            do
            {
                flag = true;
            
                mark = Convert.ToInt32(Console.ReadLine());

                if (mark < minMark || mark > maxMark)
                {
                    flag = false;
                    Console.WriteLine("Invalid Input. Please Provide Marks in the Correct Range.");
                }
            } while (!flag);

            return mark;

        }


        public void CheckResult(int mark1, int mark2, int mark3)
        {
            total = mark1 + mark2 + mark3;

            if (mark1 >= passMark && mark2 >= passMark && mark3 >= passMark)
            {
                result = "Passed!";
            }
            else
            {
                result = "Failed!";
            }
        }

        public void DisplayResult()
        {

            Console.WriteLine("*** ID : {0}  ", id);
            Console.WriteLine("*** Name : {0}  ", name);
            Console.WriteLine("*** Total Marks : {0}  ", total);
            Console.WriteLine("*** Result : {0} *** ", result);
        }

        public static void Main()
        {
            int m1, m2, m3;

            Console.WriteLine("\n**************  STUDENT PROGRESS REPORT ****************");

            Student s1 = new Student();
            s1.ReadData();
            Console.WriteLine("Enter First Mark:");
            m1 = s1.ReadMarks();
            Console.WriteLine("Enter Second Mark:");
            m2 = s1.ReadMarks();
            Console.WriteLine("Enter Third Mark:");
            m3 = s1.ReadMarks();
            s1.CheckResult(m1, m2, m3);
            s1.DisplayResult();

            Console.ReadKey();
        }

    }
}

