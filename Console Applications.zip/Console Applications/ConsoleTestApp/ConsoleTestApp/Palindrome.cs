﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class Palindrome
    {
        String original,result;

        public void ReadData()
        {
            Console.WriteLine("Enter a String");
            original = Console.ReadLine();
        }

        public void CheckPalindrome()
        {
            if (ReverseString(original) == original)
            {
                result = "Palindrome";
            }
            else
            {
                result = "Not Palindrome";
            }
        }

        public static String ReverseString(String temp)
        {
            String reverse = "";
            int length = temp.Length-1;
            while (length >= 0)
            {
                reverse += temp[length];
                length = length - 1;
            }

            return reverse;
        }

        private void DisplayResult()
        {
            Console.WriteLine("The String {0} is {1}",original,result);
        }

        public static void Main()
        {
            Palindrome obj = new Palindrome();
            obj.ReadData();
            obj.CheckPalindrome();
            obj.DisplayResult();
            Console.ReadKey();
        }

      
    }
}
