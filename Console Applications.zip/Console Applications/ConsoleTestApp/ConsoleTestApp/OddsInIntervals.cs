﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTestApp
{
    class OddsInIntervals
    {

        int interval1, interval2;

        public void ReadIntervals()
        {
            Console.WriteLine("Enter The First Number ");
            interval1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter The Second Number ");
            interval2 = Convert.ToInt32(Console.ReadLine());
        }
      
        
        public void DisplayResult()
        {
            Console.WriteLine("The Numbers are");
            for (int i = interval1; i <= interval2; i++)
            {

                if (i % 2 == 1)
                {
                    Console.WriteLine(i);
                }
              
            }

        }

        public static void Main()
        {
            OddsInIntervals obj1 = new OddsInIntervals();
            obj1.ReadIntervals();
            obj1.DisplayResult();
            Console.ReadKey();
        }


    }
}
