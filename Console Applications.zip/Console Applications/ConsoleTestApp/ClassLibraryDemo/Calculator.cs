﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryDemo
{
   public class Calculator
    {
        public static void Display()
        {
            Console.WriteLine("I am within DLL Project. ");
        }
    }
}
