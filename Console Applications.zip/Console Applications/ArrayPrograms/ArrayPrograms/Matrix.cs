﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayPrograms
{

    class MatrixDemo
    {

        public static void Main()
        {
            Console.WriteLine("Enter First Matrix : ");
            Matrix matrix1 = new Matrix();
            matrix1.ReadMatrix();
         
            Console.WriteLine("Enter Second Matrix : ");
            Matrix matrix2 = new Matrix();
            matrix2.ReadMatrix();     

            Console.WriteLine("The sum is : ");
            Matrix matrix3 = new Matrix();
            matrix3.AddMatrix(matrix1, matrix2);
          
            matrix3.DisplayMatrix();

            Console.WriteLine("The Difference is : ");
            Matrix matrix4 = new Matrix();
            matrix4.SubtractMatrix(matrix1, matrix2);
            matrix4.DisplayMatrix();

            Console.ReadKey();

        }
    }
    class Matrix
    {
        int row, column;
        int[,] numbers;

     
        public void ReadMatrix()
        {
            Console.Write("Enter rows : ");
            row = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter columns : ");
            column = Convert.ToInt32(Console.ReadLine());
            numbers = new int[row, column];

            Console.WriteLine("Enter the Numbers : - ");

            for(int i = 0; i < row; i++)
            {
                for(int j = 0; j < column; j++)
                {
                    numbers[i,j] = Convert.ToInt32(Console.ReadLine());
                }
                
            }
        }

        public void DisplayMatrix()
        {
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < column; j++)
                {
                    Console.Write(numbers[i, j]+" ");
                    
                }
                Console.WriteLine();

             

            }
        }

        public void AddMatrix(Matrix matrix1,Matrix matrix2)
        {
            row = matrix1.row;
            column = matrix1.column;
            numbers = new int[row, column];
          
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < column; j++)
                {
                    numbers[i,j] = matrix1.numbers[i, j] + matrix2.numbers[i, j];

                }
            }

        }

        public void SubtractMatrix(Matrix matrix1, Matrix matrix2)
        {

            row = matrix1.row;
            column = matrix1.column;
            numbers = new int[row, column];

            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < column; j++)
                {
                   numbers[i, j] = matrix1.numbers[i, j] - matrix2.numbers[i, j];

                }
            }

        }

    }
}
