﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayPrograms
{
    class SortArray
    {
        int limit;
        int[] numbers = new int[20];

        public void ReadData()
        {
            Console.Write("Enter The Limit : ");
            limit = Convert.ToInt32(Console.ReadLine());
           
            Console.WriteLine("Enter the Numbers : - ");

            for (int i = 0; i < limit; i++)
            {
                numbers[i] = Convert.ToInt32(Console.ReadLine());
             
            }
        }

        public void Sort()
        {
            int temp;

            for (int i = 0; i < limit; i++)
            {
                for (int j = i + 1; j < limit; j++)
                {
                    if (numbers[i] > numbers[j])
                    {
                        temp = numbers[i];
                        numbers[i] = numbers[j];
                        numbers[j] = temp;
                    }

                }

            }
        }
        public void DisplayArray()
        {
                for (int i = 0; i < limit; i++)
                {
                    Console.Write(numbers[i] + " ");

                }
        }

        public static void Main()
        {           
            SortArray obj = new SortArray();
            obj.ReadData();
            obj.Sort();
            Console.WriteLine("The Sorted Array is");
            obj.DisplayArray();
            Console.ReadKey();

        }
    }
}
