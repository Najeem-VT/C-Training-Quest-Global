﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayPrograms
{
    class BinarySearch
    {
        int num,limit;
        string result;
        int[] numbers = new int[100];

        public void ReadData()
        {
            Console.Write("Enter The Limit : ");
            limit = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the Numbers : - ");

            for (int i = 0; i < limit; i++)
            {
                numbers[i] = Convert.ToInt32(Console.ReadLine());

            }

            Console.Write("Enter The Number to Search : ");
            num = Convert.ToInt32(Console.ReadLine());
        }

        public void Sort()
        {
            int temp;

            for (int i = 0; i < limit; i++)
            {
                for (int j = i + 1; j < limit; j++)
                {
                    if (numbers[i] > numbers[j])
                    {
                        temp = numbers[i];
                        numbers[i] = numbers[j];
                        numbers[j] = temp;
                    }

                }

            }
        }

        public void SearchNumber()
        { 
            Sort();
            int low = 0, high = limit - 1;
            int middle;
            middle = (low + high) / 2;
            bool flag = false;

            do
            {
                if (num == numbers[middle])
                {
                    flag = true;
                    break;
                }
                else if (num > numbers[middle])
                {
                    low = middle + 1;
                  
                    middle = (low + high) / 2;

                }
                else
                {
                   
                    high = middle - 1;
                    middle = (low + high) / 2;
                }
            } while (low <= high);

            if (flag)
            {
                Console.Write("The Number {0} Found.", num);
            }
            else
            {
                Console.Write("The Number {0} Not Found.", num);
            }
          
        }

        public static void Main()
        {
            BinarySearch obj = new BinarySearch();
            obj.ReadData();
            obj.SearchNumber();

            Console.ReadKey();

        }

    }
}
