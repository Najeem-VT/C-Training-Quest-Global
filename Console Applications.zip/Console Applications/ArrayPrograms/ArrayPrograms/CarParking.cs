﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayPrograms
{
    class CarParking
    {
        int[] parkingArea = new int[10];
        int limit;

        CarParking(int limit)
        {
            this.limit = limit;
        }

        public void ParkCar()
        {
            bool flag = false;
            for(int i = 1; i <= limit; i++)
            {
                if (parkingArea[i] == 0)
                {
                    parkingArea[i] = 1;
                    flag = true;
                    break;
                }
            }
            if (flag)
            {
                
                Console.WriteLine("Your Car is Parked Successfully!\n");
            }
            else
            {
                Console.WriteLine("Sorry! There is no Parking Space Available!\n");
            }
        }

        public void UnParkCar()
        {
            int mySlot;
            Console.Write("Enter Your Parking Slot Number : ");
            mySlot = Convert.ToInt32(Console.ReadLine());
            
            if (parkingArea[mySlot] == 1)
            {
                parkingArea[mySlot] = 0;
                Console.WriteLine("Your Car is UnParked Successfully!\n");
            }
            else
            {
                Console.WriteLine("There is No Car Parked in that Slot!\n");
            }
                    
        }

        public void ViewSlots()
        {
            String status;
            Console.WriteLine("---- Car Parking Area ----");
            for (int i = 1; i <= limit; i++)
            {
                if (parkingArea[i] == 1)
                {
                    status = "Not Available";
                }
                else
                {
                    status = "Available";
                }
                Console.WriteLine("Slot : {0}  - {1}\n",i, status);
            }
        }

        public static void Main()
        {
            int option;
            CarParking car = new CarParking(7);

            do
            {
                Console.Write("******* Car Parking System **********\n");
                Console.Write("Please Select an Option\n");
                Console.Write("1 => Park Car\n2 => UnPark Car\n3 => View Slots\n4 => Exit\n");
                option = Convert.ToInt32(Console.ReadLine());
           
                switch (option)
                {
                    case 1:
                        car.ParkCar();
                        break;
                    case 2:
                        car.UnParkCar();
                        break;
                    case 3:
                        car.ViewSlots();
                        break;
                    case 4:
                        System.Environment.Exit(0);
                        break;
                    default:
                        Console.Write("Please Provide Correct Input!");
                        break;
                }
            } while (true);

            Console.ReadKey();

        }
    }
}
