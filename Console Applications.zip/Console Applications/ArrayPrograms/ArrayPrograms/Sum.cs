﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayPrograms
{
    public class Sum
    {
        int limit, sum;
        int[] numbers = new int[100];

        Sum(int limit)
        {
            this.limit = limit;
        }

        public void ReadData()
        {

            Console.WriteLine("Enter the Numbers");

            for(int index = 0; index < limit; index++)
            {
                numbers[index] = Convert.ToInt32(Console.ReadLine());
            }
        }

        public void FindSum()
        {
            for (int index = 0; index < limit; index++)
            {
                sum+=numbers[index];
            }
        }

        public void DisplayResult()
        {
            Console.WriteLine("The Sum of the values is {0}",sum);
        }    

        public static void Main()
        {
            Sum obj1 = new Sum(5);
            obj1.ReadData();
            obj1.FindSum();
            obj1.DisplayResult();

            Console.ReadKey();
        }
    }
}
