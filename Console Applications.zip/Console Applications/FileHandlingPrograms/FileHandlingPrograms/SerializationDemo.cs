﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace FileHandlingPrograms
{
    class SerializationDemo
    {
        public static void Main()
        {
            FileStream stream = new FileStream("C:\\Users\\1028259\\Desktop\\account.txt", FileMode.OpenOrCreate);
            BinaryFormatter formatter = new BinaryFormatter();

            Account account1 = new Account(101,220);
            formatter.Serialize(stream,account1);
            stream.Close();

            Console.WriteLine("Account object has been deserialized..");
            Deserialized();
            Console.ReadKey();
        }


        public static void Deserialized()
        {
            FileStream stream = new FileStream("C:\\Users\\1028259\\Desktop\\account.txt", FileMode.OpenOrCreate);
            BinaryFormatter formatter = new BinaryFormatter();

            Account account = (Account)formatter.Deserialize(stream);
            account.Display();

            stream.Close();
        }

    }

    [Serializable]
    class Account
    {
        public int ID { get; set; }
        public int Balance { get; set; }

        public Account(int id,int balance)
        {
            ID = id;
            Balance = balance;
        }

        public void Display()
        {
            Console.WriteLine("ID : "+ID);
            Console.WriteLine("Balance : " + Balance);
        }
    }
}
