﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileHandlingPrograms
{
    class FileStreamDemo1
    {
        static void Main(string[] args)
        {
            FileStream datafile1 = new FileStream("C:\\Users\\1028259\\Desktop\\data1.txt", FileMode.OpenOrCreate);

            for (int ii = 65; ii <= 90; ii++)
            {
                datafile1.WriteByte((Byte)ii);
            }

            datafile1.Close();

            Console.WriteLine("File Created Successfully!");

            Console.WriteLine("File Reading Operation ");
            FileStream data1OutFile = new FileStream("C:\\Users\\1028259\\Desktop\\data1.txt", FileMode.OpenOrCreate);
            int i = 0;
            while ((i = data1OutFile.ReadByte()) != -1)
            {
                Console.Write((char)i);
            }
            data1OutFile.Close();
            Console.ReadKey();
        }
    }
}
