﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModuleTest2
{
 
    class Salary
    {
        public static int noEmployees;
        int[] employeeSalary;

        public Salary()
        {
            Console.Write("Enter the No.of Employees: ");          
            noEmployees = Convert.ToInt32(Console.ReadLine());      // Read No.of Employees
            employeeSalary = new int[noEmployees];
        }

        public int this[int index]
        {
            get
            {
                return employeeSalary[index];
            }
            set
            {
                employeeSalary[index] = value;
            }
        }

 

        public static void Main()
        {
            int option;


            Salary salary = new Salary();

            do
            {
                Console.WriteLine("\n******Menu ************");
                Console.WriteLine("1 => Read Details\n2 => Display Employee Details\n3 => Particular Employee Details\n4 => Exit\n");
                option = Convert.ToInt32(Console.ReadLine());       // Options Menu

                switch (option)
                {
                    case 1:
                        for(int i=0;i< noEmployees; i++)
                        {
                            Console.WriteLine("Enter the Salary of Next Employee");
                            salary[i]= Convert.ToInt32(Console.ReadLine());
                        }
                        break;
                    case 2:
                        Console.WriteLine("**** Salary Details of All the Employees ****");
                        for (int i = 0; i < noEmployees; i++)
                        {
                            Console.Write("Salary of  Employee {0}: {1}\n", i, salary[i]);

                        }
                        break;
                    case 3:
                        int id;
                        Console.Write("Enter the Index of the particular Employee: ");
                        id = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Salary of the Employee With Index {0}: {1} ", id, salary[id]);
                        break;
                    case 4:
                        System.Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid Input! Please Choose a Correct Option.");
                        break;
                }

            } while (true);

            Console.ReadKey();
        }
    }
}
