﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModuleTest2
{
    class SalesAmountReport
    {
        int noMonths;
        int[] sales;

        public SalesAmountReport()
        {
            Console.Write("Enter the No.of Months: ");
            noMonths = Convert.ToInt32(Console.ReadLine());
            sales = new int[noMonths];
        }

        public void ReadData()      // Method to Read Sales Amounts
        {
            

            Console.WriteLine("Enter the sales amounts: ");

            for(int i=0;i< noMonths; i++)
            {
                try
                {
                    sales[i] = Convert.ToInt32(Console.ReadLine());

                }
                catch
                {
                    Console.WriteLine("Please Enter a valid integer");
                    i--;
                }
            }


        }

        public void sortArray()         // Method to Sort Sales Array
        {
            int temp;

            for(int i=0;i< noMonths-1; i++)
            {
                for(int j = i + 1; j < noMonths; j++)
                {
                    if (sales[i] >= sales[j])
                    {
                        temp = sales[i];
                        sales[i] = sales[j];
                        sales[j] = temp;
                    }
                }
            }
        }

        public void displaySalesReport()       // Method to print the sales report
        {
            int i = 1;
            Console.WriteLine("**** The Sales Report of {0} Months *****",noMonths);
            foreach (int sale in sales)
            {
                Console.WriteLine("Month {0} : {1}",i,sale);
                i++;
              
            }
        }


        static void Main(string[] args)
        {
            SalesAmountReport report = new SalesAmountReport();
            report.ReadData();
            report.sortArray();
            report.displaySalesReport();
            Console.ReadKey();

        }

    }

    
}
