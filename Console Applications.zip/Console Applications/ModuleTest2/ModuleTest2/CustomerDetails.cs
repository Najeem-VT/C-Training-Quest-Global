﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModuleTest2
{
    class CustomerDetails
    {
        int noCustomer;
        public Customer[] customer; 


        public CustomerDetails()
        {
            Console.Write("Enter the No.of Customers: ");
            noCustomer = Convert.ToInt32(Console.ReadLine());
            customer = new Customer[noCustomer];
        }

        public void ReadCustomerDetails()       // Method to Read Customer Data
        {
            for(int i=0;i< noCustomer; i++)
            {
                Console.WriteLine("Enter the Details of Next Customer: ");
                customer[i] = new Customer();
                Console.Write("Id :");
                customer[i].Id= Convert.ToInt32(Console.ReadLine());
                Console.Write("Name :");
                customer[i].Name = Console.ReadLine();
                Console.Write("Phone :");
                customer[i].Phone= Convert.ToInt64(Console.ReadLine());
                

            }
        }

        public void DisplayCustomerDetails()       // Method to Display Customer Data
        {
            Console.WriteLine("******* Details of the Customers *****");
            for (int i = 0; i < noCustomer; i++)
            {
                Console.WriteLine("***********************");
                Console.WriteLine("ID: "+ customer[i].Id);
                Console.WriteLine("NAME: " + customer[i].Name);
                Console.WriteLine("PHONE: " + customer[i].Phone);
                Console.WriteLine("USER TYPE: " + customer[i].UserType);
                Console.WriteLine("***********************");
            }
        }


        public static void Main()
        {
            CustomerDetails customerObj = new CustomerDetails();
            customerObj.ReadCustomerDetails();
            customerObj.DisplayCustomerDetails();

            Console.ReadKey();

        }
    }

    class Customer      // Customer Class
    {
        int id;
        long  phone;
        string name;
        string type;

        enum userType
        {
            retail,
            wholesale
        }
        
        public Customer()
        {
            
            Console.Write("Enter User Type(retail/wholesale)  : ");
            type = Console.ReadLine();
        }
        public int Id       // Property Id
        {
            get { return id; }
            set { id = value; }
        }

        public string Name  //Property Name
        {
            get { return name; }
            set { name = value; }
        }

        public long Phone       // Property Phone
        {
            get { return phone; }
            set { phone = value; }
        }

        public Enum UserType       // Property UserType
        {
            get {
                if(type== "retail")
                {
                    return userType.retail;
                }
                else{
                    return userType.wholesale;
                }
            }
            
        }

    }
}
