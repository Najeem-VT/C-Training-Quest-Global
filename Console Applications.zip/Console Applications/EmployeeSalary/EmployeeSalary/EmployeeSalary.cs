﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandling
{
    class SalaryOutOfBound : Exception
    {
        public SalaryOutOfBound()
        {
        
            Console.WriteLine("Salary is out of bound");
        }
    }
    class EmployeeSalary
    {
        int salary;

        
        public void ReadData()
        {
            bool flag = true;
            do
            {
                
                try
                {
                    Console.Write("Enter Salary : ");
                    salary = Convert.ToInt32(Console.ReadLine());

                    if(salary<1000 || salary > 10000)
                    {
                        throw new SalaryOutOfBound();
                    }
                    flag = false;
                }
                catch (SalaryOutOfBound m)
                {
                    Console.Write("Error : " + m.Message.ToString());
                    Console.Write("Enter a Valid Mark");
                }
            } while (flag);
            
            
            
        }
    
        static void Main(string[] args)
        {
            EmployeeSalary salaryObj = new EmployeeSalary();
            salaryObj.ReadData();
            salaryObj.DisplayData();
            Console.ReadKey();
        }
    }
}
