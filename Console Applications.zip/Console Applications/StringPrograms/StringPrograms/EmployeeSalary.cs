﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringPrograms
{
    class EmployeeSalary
    {
        static int noEmp;
        static Employee[] employees = new Employee[100];
        static void Main(string[] args)
        {
            Console.Write("Enter the No.of Employees :");
            noEmp = Convert.ToInt32(Console.ReadLine());
            for (int i=0;i< noEmp; i++)
            {
                Console.WriteLine("\nEnter the Details of Another Employee :");
                employees[i] = new Employee();
                employees[i].ReadData();
                employees[i].FindHRA();
                employees[i].FindDA();
                employees[i].FindPF();
                employees[i].FindNetSalary();
            }

            Console.WriteLine("\n********Employee Details******\n");
            for (int i = 0; i < noEmp; i++)
            {
                Console.WriteLine(employees[i]);

            }

            Console.ReadKey();

        }
    }

    class Employee
    {
        int id;
        String name;
        double basicPay, hra, da, pf, netSalary;

        public void ReadData()
        {
            Console.Write("Enter the ID :");
            id = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the Name :");
            name = Console.ReadLine();
            Console.Write("Enter the Basic Pay :");
            basicPay = Convert.ToInt32(Console.ReadLine());
        }


        public void FindHRA()
        {
            hra = basicPay * 0.1;
        }

        public void FindDA()
        {
            da = basicPay * 0.05;
        }

        public void FindPF()
        {
            pf = basicPay * 0.12;
        }

        public void FindNetSalary()
        {
            netSalary = basicPay + da + hra - pf;
        }

        public override string ToString()
        {
            String output;

            output = "*************************************************\n";
            output += "Employee ID : "+id+"\n";
            output += "Employee Name : " + name + "\n";
            output += "Basic Pay : " + basicPay + "\n";
            output += "HRA : " + hra + "\n";
            output += "DA : " + da + "\n";
            output += "PF : " + pf + "\n";
            output += "Net Salary : " + netSalary + "\n";
            return output;
        }
    }
}
