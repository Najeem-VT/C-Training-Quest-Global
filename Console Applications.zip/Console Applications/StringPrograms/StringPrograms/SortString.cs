﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringPrograms
{
    class SortString
    {
        string originalString, sortedString;
        char[] arr;
        public static void Main()
        {
            SortString obj = new SortString();
            obj.ReadString();
            obj.Sort();
            obj.DisplayResult();

            Console.ReadKey();

        }


        public void ReadString()
        {
            Console.Write("Enter A String : ");
            originalString = Console.ReadLine();
            arr = originalString.ToCharArray();
        }

        public void DisplayResult()
        {
            sortedString = arr.ToString();
            Console.Write("Sorted String : {0}", sortedString);

        }
        public void Sort()
        {
            

        }

    }
}
