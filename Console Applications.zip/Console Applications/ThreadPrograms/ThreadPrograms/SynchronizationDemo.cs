﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ThreadPrograms
{
    class SynchronizationDemo
    {
        public static void Main()
        {
            Printer printer1 = new Printer();
            Thread thread1 = new Thread(printer1.PrintTable);
            thread1.Start();

            Thread thread2 = new Thread(printer1.PrintTable);
            thread2.Start();

            Console.ReadKey();

        }
    }

    class Printer
    {
        public void PrintTable()
        {
            lock (this)
            {
                for (int i = 0; i <= 10; i++)
                {
                    Thread.Sleep(1000);
                    Console.WriteLine(i);
                }
            }
            
        }
    }
}
