﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ThreadPrograms
{
    class ThreadJoinDemo
    {
        public static void Main()
        {

            Thread thread1 = Thread.CurrentThread;
            thread1.Name = "Main Thread";
            Console.WriteLine("Main Thread : " + thread1.Name);



            Thread childThraed1 = new Thread(PrinterClass.ChildThread1);
            childThraed1.Start();

            Thread childThraed2 = new Thread(PrinterClass.ChildThread2);
            childThraed2.Start();

            childThraed1.Join();    // Main thread (Calling thread) wait until this thread finishes its execution
            childThraed2.Join();    // Main thread (Calling thread) wait until this thread finishes its execution

            Console.WriteLine("--------------------------------");
            Console.WriteLine("Main Thread Finished Execution!");
            Console.WriteLine("--------------------------------");

            Console.ReadKey();

        }
    }

    class PrinterClass
    {
        public static void ChildThread1()
        {
            Console.WriteLine("I am in child thread 1");

            for(int i = 1; i <= 10; i++)
            {
                Console.Write(i+ " ");
            }
            Console.WriteLine();
            Console.WriteLine(" child thread 1 completed");
        }

        public static void ChildThread2()
        {
            //Thread.Sleep(1000);

            Console.WriteLine("I am in child thread 2");

            for (int i = 1; i <= 50; i++)
            {
                Console.Write(i + " ");
            }
            Console.WriteLine();
            Console.WriteLine(" child thread 2 completed");
        }
    }
}
