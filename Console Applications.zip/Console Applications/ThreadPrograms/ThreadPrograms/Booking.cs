﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
namespace cs_week3.ThreadDemo
{
    class ThreadSynchronizationDemo
    {

        static void Main(string[] args)
        {

            int[] seats = new int[3000];
            for (int j = 0; j < 3000; j++)
            {
                seats[j] = 0;

            }
            BookingAgent[] bookingAgent = new BookingAgent[10];

            SeatBookings seatBookings = new SeatBookings(seats);
            //  BookingAgent bookingAgent = new BookingAgent(seatBookings, 1);
            Thread[] bookingAgentThreads = new Thread[10];

            for (int agentCode = 0; agentCode < 10; agentCode++)
            {
                bookingAgent[agentCode] = new BookingAgent(seatBookings, agentCode);
                bookingAgentThreads[agentCode] = new Thread(new ThreadStart(bookingAgent[agentCode].BookSeat));
                bookingAgentThreads[agentCode].Start();


            }


            Console.ReadLine();


        }




    }

    class BookingAgent
    {
        private SeatBookings seatBookings;
        private int agentCode;
        private Random randomNumbers = new Random();
        public BookingAgent(SeatBookings seatBookings, int agentCode)
        {
            this.seatBookings = seatBookings;
            this.agentCode = agentCode;

        }

        public int GetAgentCode()
        {
            return agentCode;
        }


        public void BookSeat()
        {

            do
            {
                int seatNo = (int)(randomNumbers.Next(0, 3000));

                // Console.WriteLine("Booking Agent Code :" + agentCode);
                seatBookings.BookSeat(seatNo, agentCode);
                if (seatBookings.DoubleBooked(seatNo))
                {
                    Console.WriteLine("************************Seat Number :" + seatNo + " doble booked!");

                }


            } while (seatBookings.totalBooked < 3000);
            Console.WriteLine("All booking compleate");


        }







    }



    class SeatBookings
    {
        private int[] seats;
        public int totalBooked = 0;
        public SeatBookings(int[] s)
        {
            seats = s;
        }
        public bool isAvailable(int seatNo)
        {

            return (seats[seatNo] == 0);
        }
        public void BookSeat(int seatNo, int agenctCode)
        {
            //   lock (this)
            //  Monitor.Enter(this);

            {
                if (isAvailable(seatNo))
                {
                    seats[seatNo]++;
                    totalBooked++;
                    Console.WriteLine("Seat " + seatNo + " booked by agent : " + agenctCode + " . total booked= " + totalBooked);
                }
            }
            //  Monitor.Exit(this);
        }

        public bool DoubleBooked(int seatNo)
        {
            return (seats[seatNo] > 1);

        }
    }


}
