﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ThreadPrograms
{
    class ThreadTableDemo
    {
        static void Main(string[] args)
        {
            Table table1 = new Table(5,1000);
            Thread thread1 = new Thread(table1.GenerateTable);
            thread1.Start();
          

            Table table2 = new Table(8,2000);
            Thread thread2 = new Thread(table2.GenerateTable);
            thread2.Start();
          

            Console.ReadKey();
        }
    }

    class Table
    {
        private int _number;
        private int _sleep;

        public Table(int num,int sleep)
        {
            _number = num;
            _sleep = sleep;
        }

        public void GenerateTable()
        {
            Thread.Sleep(_sleep);
            for(int iterator = 1; iterator <= 10; iterator++)
            {
                Console.WriteLine("{0} * {1} = {2}", iterator, _number, iterator * _number);
            }

        }
    }
}
