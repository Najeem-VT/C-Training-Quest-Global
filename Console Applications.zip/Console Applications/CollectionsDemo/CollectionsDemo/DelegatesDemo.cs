﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsDemo
{
    public delegate void Calculate(int val1, int val2);
    class DelegatesDemo
    {
        public static void Main()
        {
            Calculate calculate = new Calculate(Calculator1.Sum);

            Calculator1 calculator = new Calculator1();
            calculate+=calculator.Mul;

            calculate += Calculator2.Sub;

           // calculate -= Calculator1.Sum;

            calculate(10,20);
            Console.ReadKey();
        }
    }

    class Calculator1
    {
        public static void Sum(int val1,int val2)
        {
            Console.WriteLine(val1 + val2);
        }

        public void Mul(int val1, int val2)
        {
            Console.WriteLine(val1 * val2);
        }
    }

    class Calculator2
    {
        public static void Sub(int val1, int val2)
        {
            Console.WriteLine(val1 - val2);
        }
    }
}
