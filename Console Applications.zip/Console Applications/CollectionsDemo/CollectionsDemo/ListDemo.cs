﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsDemo
{
    class ListDemo
    {
        static void Main(string[] args)
        {

            List<string> names = new List<String>();
            names.Add("Akhil");
            names.Add("Gopi");
            names.Add("Ravi");
            names.Add("Sai");
            //names.Remove("Gopi");
            //names.Add(123);
            //names.Add(new Message());
            //names.RemoveAt(0);
            //names.RemoveRange(2, 2);
            //names.Reverse();
            //names.Sort();
            names.Insert(0, "James1");


            foreach (var name in names)
            {
                Console.WriteLine(name);
            }

            Console.ReadKey();



        }
    }
}
