﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsDemo
{
    class HashTableDemo
    {
        public static void HashTable()
        {
            Hashtable ht = new Hashtable();
            ht.Add("001", "NAJEEM");
            ht.Add("002", "gokul");
            ht.Add("003", "ajmal");

            if (ht.ContainsValue("Abhishek"))
            {
                Console.WriteLine("The STUDENT is already in te list.");
            }
            else
            {
                ht.Add("004", "Abhishek");
            }



            ICollection key = ht.Keys;
            foreach (string k in key)
            {
                Console.WriteLine(k + " : " + ht[k]);
            }

        }

        public static void Main()
        {
            HashTable();
            Console.ReadKey();
        }
    }
}
