﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsDemo
{
    public delegate bool IsPassedDelegate(Student student);

    class DelegateStudent
    {
        public static void Main()
        {
            List<Student> studentList = new List<Student>();
            studentList.Add(new Student { ID = 101, Name = "Gopi", Mark = 100});
            studentList.Add(new Student { ID = 102, Name = "Ravi", Mark = 40 });
            studentList.Add(new Student { ID = 103, Name = "Sam", Mark = 83 });

            Console.WriteLine("List of Students Passed");

            IsPassedDelegate isPassedDelegate = new IsPassedDelegate(IsPassed);


            Student.GetPassedList(studentList, isPassedDelegate);
            Console.ReadKey();
        }

        public static bool IsPassed(Student student)
        {
            bool passed = false;
            if (student.Mark >= 45)
            {
                student.Result = "Passed";
                passed = true;
            }
            else
            {
                student.Result = "Failed";
                passed = false;
            }
            return passed;
        }
    }

    public class Student
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int Mark { get; set; }
        public string Result { get; set; }

        public static void GetPassedList(List<Student> students, IsPassedDelegate isPassedDelegate)
        {

            foreach (Student student in students)
            {
                if (isPassedDelegate(student))
                {
                    Console.WriteLine("Student ID : " + student.ID);
                    Console.WriteLine("Student Name :" + student.Name);
                    Console.WriteLine("Marks : " + student.Mark);
                    Console.WriteLine("Result : " + student.Result);
                    Console.WriteLine("***********************************************");
                }
            }

        }
    }
}
