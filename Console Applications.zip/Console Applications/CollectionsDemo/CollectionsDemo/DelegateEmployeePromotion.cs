﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsDemo
{
    class DelegateEmployeePromotion
    {
        public static void Main() { 
        List<Employee> employeeList = new List<Employee>();
        employeeList.Add(new Employee{ID=101,Name="Gopi",Salary=1000,Experience=4});
        employeeList.Add(new Employee { ID = 102, Name = "Ravi", Salary = 4000, Experience = 6 });
        employeeList.Add(new Employee { ID = 103, Name = "Sam", Salary = 5000, Experience = 7 });

            Console.WriteLine("List of employees eligible for promotion");
        Employee.GetPromotedList(employeeList);
        Console.ReadKey();
        }
    }

    class Employee
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int Experience { get; set; }
        public int Salary { get; set; }

        public static void GetPromotedList(List<Employee> employees)
        {

            foreach(Employee employee in employees)
            {
                if (employee.Experience >= 5)
                {
                    Console.WriteLine("Employee ID : "+employee.ID);
                    Console.WriteLine("Employee NAME : " + employee.Name);
                    Console.WriteLine("Employee SALARY : " + employee.Salary);
                    Console.WriteLine("Employee EXPERIENCE : " + employee.Experience);
                    Console.WriteLine("***********************************************");
                }
            }

        }
    }
}
