﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsDemo
{

    public delegate bool IsPromotableDelegate(Employee2 employee);

    class DelegateEmployeeCallback
    {
        public static void Main()
        {
            List<Employee2> employeeList = new List<Employee2>();
            employeeList.Add(new Employee2 { ID = 101, Name = "Gopi", Salary = 1000, Experience = 4 });
            employeeList.Add(new Employee2 { ID = 102, Name = "Ravi", Salary = 4000, Experience = 6 });
            employeeList.Add(new Employee2 { ID = 103, Name = "Sam", Salary = 5000, Experience = 7 });

            Console.WriteLine("List of employees eligible for promotion");

            IsPromotableDelegate isPromotableDelegate = new IsPromotableDelegate(IsPromotable);

            
            Employee2.GetPromotedList(employeeList,isPromotableDelegate);
            Console.ReadKey();
        }

        public static bool IsPromotable(Employee2 employee)
        {
            bool eligible = false;
            if (employee.Experience >= 7)
            {
                eligible= true;
            }
            else
            {
                eligible= false;
            }
            return eligible;
        }
    }

    public class Employee2
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int Experience { get; set; }
        public int Salary { get; set; }

        public static void GetPromotedList(List<Employee2> employees, IsPromotableDelegate isPromotableDelegate)
        {

            foreach (Employee2 employee in employees)
            {
                if (isPromotableDelegate(employee))
                {
                    Console.WriteLine("Employee ID : " + employee.ID);
                    Console.WriteLine("Employee NAME : " + employee.Name);
                    Console.WriteLine("Employee SALARY : " + employee.Salary);
                    Console.WriteLine("Employee EXPERIENCE : " + employee.Experience);
                    Console.WriteLine("***********************************************");
                }
            }

        }
    }
}
