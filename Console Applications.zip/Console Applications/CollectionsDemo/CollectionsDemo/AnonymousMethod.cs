﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsDemo
{
    public delegate void Print(int value);

    //class AnonymousMethod
    //{
    //    public static void Main()
    //    {
    //        Print print = delegate (int val)
    //        {
    //            Console.WriteLine("Inside Anonymous Method. Value :" + val);
    //        };
    //        print(1000);
    //        Console.ReadKey();
    //    }
    //}


    class AnonymousMethod
    {

        public static void PrintHelperMethod(Print printDel, int val)
        {
            val += 10;
            printDel(val);
        }
        public static void Main()
        {
            PrintHelperMethod(delegate (int val) { Console.WriteLine("Anonymous Method.Value :" + val); }, 100);
            Console.ReadKey();
        }
    }
}
