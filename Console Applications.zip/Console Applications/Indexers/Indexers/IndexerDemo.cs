﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Indexers
{
    class IndexerDemo
    {
        static void Main(string[] args)
        {
            Marks m1 = new Marks();
            
            for(int i = 0; i < 5; i++)
            {
                m1[i] = m1[i] + 10;
            }

            for (int i = 0; i < 5; i++)
            {
                Console.Write(m1[i]+" ");
            }

            Console.ReadKey();
        }
    }

    class Marks
    {
        public int[] mark = new int[5] { 100, 150, 200,300,400};

        public int this[int index]
        {
            get { return mark[index]; }
            set { mark[index] = value; }
        }
    }
}
