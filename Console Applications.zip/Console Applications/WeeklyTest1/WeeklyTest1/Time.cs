﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTest1
{
    class Time
    {
        int hour, minute, second;

        public Time() {

        }


        public Time(int hour,int minute,int second)
        {
            this.hour = hour;
            this.minute = minute;
            this.second = second;
        }
        
        public void Display()
        {
            Console.WriteLine(" {0} Hours, {1} Minutes, {2} Seconds",hour,minute,second);
        }

        public static Time operator +(Time time1, Time time2)   //Method to Add Two Time
        {
            Time t5 = new Time();
            t5.hour = time1.hour + time2.hour;
            t5.minute = time1.minute + time2.minute;
            t5.second = time1.second + time2.second;

            if (t5.second >= 60)
            {
                t5.minute++;
                t5.second %= 60;
            }
            if (t5.minute >= 60)
            {
                t5.hour++;
                t5.minute %= 60;
            }

            return t5;

        }


        public static Time operator -(Time time1, Time time2)    //Method to Subtract Two Time
        {
            Time t6 = new Time();

            int tim1 = (time1.hour * 60 * 60) + (time1.minute * 60) + time1.second;
            int tim2 = (time2.hour * 60 * 60) + (time2.minute * 60) + time2.second;
            int tim3 = Math.Abs(tim1 - tim2);

            t6.second = tim3 % 60;
            tim3 = tim3 / 60;
            t6.minute = tim3 % 60;
            t6.hour = tim3 / 60;
            return t6;

        }
        public static void Main()
        {
            Time t1 = new Time(5,30,0);
            Time t2 = new Time(3, 20, 0);
            Time t3, t4;
            t3 = t1 + t2;
            Console.Write("The sum is ");
            t3.Display();
            t4 = t1 - t2;
            Console.Write("The difference is");
            t4.Display();

            Console.ReadKey();
        }
    }
}
