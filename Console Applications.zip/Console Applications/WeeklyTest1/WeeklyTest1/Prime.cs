﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTest1
{
    public class Prime
    {
        public static void Main()
        {
            int option;
            do
            {
                Console.WriteLine("\n********** Enter an Option **********");
                Console.WriteLine("1) CHECK PRIME OR NOT\n2) PRIMES BETWEEN INTERVALS\n3) N PRIME NUMBERS\n4) EXIT\n");
                option = Convert.ToInt32(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        PrimeOrNot obj1 = new PrimeOrNot();
                        obj1.ReadData();
                        obj1.CheckPrime();
                        obj1.DisplayResult();
                        break;
                    case 2:
                        PrimeIntervals obj2 = new PrimeIntervals();
                        obj2.ReadData();
                        obj2.DisplayPrime();
                        break;
                    case 3:
                        NPrime obj3 = new NPrime();
                        obj3.ReadData();
                        obj3.DisplayPrime();
                        break;
                    case 4:
                        System.Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid Entry!");
                        break;
                }
            } while (true);
            Console.ReadKey();
        }
    }


    public class PrimeOrNot
    {
        int num;
        String res;

        public void ReadData()      // Method to Read Number
        {
            Console.WriteLine("Enter a Number");
            num = Convert.ToInt32(Console.ReadLine());
        }
        
        public void CheckPrime()    // Method to Check Whether a number is prime or not
        {
            bool flag = true;

            for(int i = 2; i < num; i++)
            {
                if (num % i == 0)
                {
                    flag = false;
                    break;
                }
            }
            if (!flag)
            {
                res = "Not Prime";
            }
            else
            {
                res = "Prime";
            }
        }

        public void DisplayResult()     // Method to Display Result
        {
            Console.WriteLine("The Number {0} is {1}",num,res);
        }
    }

    public class PrimeIntervals
    {
        int interval1, interval2;

        public void ReadData()      // Method to Read Intervals
        {
            Console.WriteLine("Enter the First Interval");
            interval1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the Second Interval");
            interval2 = Convert.ToInt32(Console.ReadLine());
        }

        public void DisplayPrime()  // Method to Display Prime Numbers in the Intervals
        {
            int num;
            Console.WriteLine("\nThe Prime Numbers are :");
            for (int no=interval1; no<=interval2; no++)
            {
                num = no;

                bool flag = true;

                for (int i = 2; i < num; i++)
                {
                    if (num % i == 0)
                    {
                        flag = false;
                        break;
                    }
                }
                if (flag)
                {
                    Console.WriteLine(num);
                } 

            }
        }

    }

    public class NPrime
    {
        int limit;


        public void ReadData()      // Method to Read Intervals
        {
            Console.WriteLine("Enter the Limit");
            limit = Convert.ToInt32(Console.ReadLine());
        }

        public void DisplayPrime()
        {
        
            int num;
            int count = 1;

            Console.WriteLine("\nThe Prime Numbers are :");

            for (int no = 1; no >= 0; no++)
                {
                    num = no;

                    bool flag = true;

                    for (int i = 2; i < num; i++)
                    {
                        if (num % i == 0)
                        {
                            flag = false;
                            break;
                        }
                    }
                    if (flag)
                    {
                        Console.WriteLine(num);
                        count++;
                    }

                if (count > limit)
                {
                    break;
                }
                }
         
        }

    }

  
}
