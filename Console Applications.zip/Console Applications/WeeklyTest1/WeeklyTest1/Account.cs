﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeeklyTest1
{
 
    public abstract class Account     
    {
        
        public readonly int accountId;
        public String name;
        static int id = 1001;
        public Account()
        {
            accountId=id;
            id++;
        }
        public abstract void CalculateInterest();   // Abstract method to calculate interest

        public static void Main()
        {
            SBAccount obj = new SBAccount();
            obj.ReadData();
            obj.CalculateInterest();
            obj.DisplayResult();
            Console.ReadKey();

            SBAccount obj2 = new SBAccount();
            obj2.ReadData();
            obj2.CalculateInterest();
            obj2.DisplayResult();
            Console.ReadKey();
        }
    }

    public class SBAccount : Account
    {

        public double principle, rateOfInterest, term, interest;
        public void ReadData()
        {
            Console.WriteLine("Enter Name");
            name = Console.ReadLine();

            Console.WriteLine("Enter the Principle Amount");
            principle = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter the Rate of Interest");
            rateOfInterest = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter the Term");
            term = Convert.ToDouble(Console.ReadLine());

        }

        public override void CalculateInterest()        // Implementing Abstract Method
        {
            interest = principle * rateOfInterest * term / 100;
        }

        public void DisplayResult()
        {
            Console.WriteLine("******* Account Details***********\n");
            Console.WriteLine("Account Id : {0}", accountId);
            Console.WriteLine("Account Name : {0}", name);
            Console.WriteLine("Principle Amount : {0}", principle);
            Console.WriteLine("Rate of Intersest : {0}", rateOfInterest);
            Console.WriteLine("Term : {0}", term);
            Console.WriteLine("Interest : {0}", interest);
            Console.WriteLine("********************\n");
        }
    }
}
