﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    class CodeGeneration
    {
       static string empCode = "EMP100";

        public CodeGeneration()
        {
            int id = Convert.ToInt32(empCode.Substring(3));
            id++;
            empCode = string.Concat("EMP",id);

        }

    


        public void DisplayDetails()
        {
            Console.WriteLine("ID : "+ empCode);
           

        }
        static void Main(string[] args)
        {
            CodeGeneration codeObj1 = new CodeGeneration();
            codeObj1.DisplayDetails();
            CodeGeneration codeObj2 = new CodeGeneration();
            codeObj2.DisplayDetails();
            CodeGeneration codeObj3 = new CodeGeneration();
            codeObj3.DisplayDetails();

            Console.ReadKey();
        }

    }
}
