﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    class PersonalDetailsStrut
    {
        
        struct PersonalDetails
        {
            public int id;
            public string name;
            public string email;
            public int phone;
            public int age;
            public DateTime dob;
            

        };

        PersonalDetails details = new PersonalDetails();

        public void ReadData()
        {
            

            //Console.Write("ID : ");          
            //details.id = Convert.ToInt32(Console.ReadLine());
            //Console.Write("NAME : ");
            //details.name = Console.ReadLine();
            //Console.Write("EMAIL : ");
            //details.email = Console.ReadLine();
            //Console.Write("PHONE : ");
            //details.phone = Convert.ToInt32(Console.ReadLine());
            Console.Write("DOB (DD/MM/YYYY) : ");
            
            //details.dob+=" "

        }

        public void FindAge()
        {

            DateTime dob = Convert.ToDateTime(details.dob);
            Console.Write(dob.ToString());



        }

        public void DisplayData()
        {
           
            //Console.WriteLine("\n******* Personal Detaiils *******");
            //Console.WriteLine("ID : "+ details.id);
            //Console.WriteLine("NAME : "+ details.name);
            //Console.WriteLine("EMAIL : " + details.email);
            //Console.WriteLine("PHONE : " + details.phone);
            Console.WriteLine("DOB : " + details.dob);
            FindAge();
            Console.WriteLine("AGE : " + details.age);
        }
        public static void Main()
        {
            PersonalDetailsStrut detaislObj = new PersonalDetailsStrut();
            detaislObj.ReadData();
            detaislObj.DisplayData();

            Console.ReadKey();
        }
    }
}
