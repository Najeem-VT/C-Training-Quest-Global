﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    class SOBException:Exception
    {
        public SOBException() {

            Console.WriteLine("Salary Out of Bound Exception :  Please Enter a Salary between(1000 - 10000)");
        }
    }

    class Employee
    {
        int noEmployees;
        int[] salary;
        public Employee()
        {
            Console.Write("Enter the Number of Employees : ");
            noEmployees = Convert.ToInt32(Console.ReadLine());
            salary = new int[noEmployees];
        }

        public void ReadSalary()
        {
            for(int i = 0; i < noEmployees; i++)
            {
                try
                {
                    Console.Write("Enter the Salary of Employee {0} : ", i + 1);
                    salary[i] = Convert.ToInt32(Console.ReadLine());

                    if (salary[i] < 1000 || salary[i] > 10000)
                    {
                        throw new SOBException();
                    }
                }
                catch (SOBException e)
                {
                    Console.Write("Exception : " + e.Message.ToString());
                    i--;
                }
                
            }
        }

        public void DisplaySalary()
        {
            Console.WriteLine("*** Salary Details ***");
            for (int i = 0; i < noEmployees; i++)
            {
                Console.WriteLine("Employee {0} : {1}", i + 1,salary[i]);
            }
        }
        public static void Main()
        {
            Employee emp = new Employee();
            emp.ReadSalary();
            emp.DisplaySalary();

            Console.ReadKey();
        }
    }
}
