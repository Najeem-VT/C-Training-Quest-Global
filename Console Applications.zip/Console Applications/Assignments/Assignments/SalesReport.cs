﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    class SalesReport
    {
        int[] sales = new int[12];

        public int this[int index]
        {
            get
            {
                return sales[index];
            }

            set
            {
                sales[index] = value;
            }
        }

     

        public static void Main()
        {
            SalesReport report = new SalesReport();
            Console.WriteLine("Enter the Sales Data of Months ");
            for (int i = 0; i < 12; i++)
            {
                Console.Write("Sales of Month {0} :", i + 1);
                report[i]= Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("**** Sales Report ");
            for (int i = 0; i < 12; i++)
            {
                Console.Write("Sales of Month {0} : {1} \n", i + 1, report[i]);
                 
            }

            Console.ReadKey();
        }

    }
}
