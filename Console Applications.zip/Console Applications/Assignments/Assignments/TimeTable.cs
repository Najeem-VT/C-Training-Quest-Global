﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments
{
    class TimeTable
    {
        public string period1, period2, period3;
        enum Days { Sun, Mon, tue, Wed, thu, Fri, Sat };

        public void ReadTimeTable()
        {
            Console.WriteLine("Enter the events planned for each of the day");
            foreach (Days day in Enum.GetValues(typeof(Days)))
            {
                Console.WriteLine("Enter the plan for {0}", day);
                Console.Write("Period 1 : ");
                Days.Sun.period1 = 5;


            }

        }

        public void DisplayTimeTable()
        {
            Console.WriteLine("*** Time Table of this week ****");
            foreach (Days day in Enum.GetValues(typeof(Days)))
            {
                //Console.WriteLine("Enter the plan for {0}", day);

            }

        }
        public static void Main()
        {
            TimeTable timetable = new TimeTable();
            timetable.ReadTimeTable();
            timetable.DisplayTimeTable();
            Console.ReadKey();
        }
    }
}
           

