﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttributesDemo
{
    class InputException
    {
        public static int ReadI()
        {
            int value = 0;
            bool flag = true;

            do
            {
                try
                {
                    value = Convert.ToInt32(Console.ReadLine());
                    flag = false;
                }
                catch
                {
                    Console.WriteLine("Wrong Value. Enter a valid Integer.");
                }

            } while (flag);
            return value;
        }

        public static void Main()
        {
            int val;
            val=InputException.ReadI();
            Console.WriteLine("The Number is " + val);
            Console.ReadKey();
        }
    
    }
}
