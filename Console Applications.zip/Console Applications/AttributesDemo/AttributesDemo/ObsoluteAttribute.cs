﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttributesDemo
{
    class ObsoluteAttribute
    {
        public static void Main()
        {
            List<int> list = new List<int>();
            list.Add(10);
            list.Add(20);
            list.Add(30);
            list.Add(40);

            int result1 = Calculator.Add(1, 2);
            int result2 = Calculator.Add(list);

            Console.WriteLine("Result 1 : {0}", result1);
            Console.WriteLine("Result 2 : {0}", result2);

            Console.ReadKey();
        }
    }

    [Obsolete("This Class is Depricated")]
    class Calculator {

        [Obsolete("New Method : int Add(List<int> numbers)")]
        public static int Add(int val1,int val2)
        {
            return val1 + val2;
        }

        public static int Add(List<int> numbers)
        {
            int sum = 0;

            foreach(int num in numbers)
            {
                sum += num;
            }

            return sum;
        }

    }


}
