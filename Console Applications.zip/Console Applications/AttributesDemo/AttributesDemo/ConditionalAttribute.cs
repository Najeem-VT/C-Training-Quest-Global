﻿#define FOOL

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttributesDemo
{
    class ConditionalAttribute
    {
        static void Main(string[] args)
        {
            Greet.GreetDebug();
            Greet.GreetTrace();

            Console.ReadKey();
        }
    }

    class Greet
    {
        [System.Diagnostics.Conditional("DEBUG")]
        public static void GreetDebug()
        {
            Console.WriteLine("Greatings from Debug");
        }

        [System.Diagnostics.Conditional("FOOL")]
        public static void GreetTrace()
        {
            Console.WriteLine("Greatings from Trace");
        }
    }
}
