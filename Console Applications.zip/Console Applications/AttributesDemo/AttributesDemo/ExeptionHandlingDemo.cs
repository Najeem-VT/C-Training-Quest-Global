﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttributesDemo
{
    class ExeptionHandlingDemo
    {
        public static void Main()
        {
            int a, b, c;
            a = 10;
            b = 5;
            c = 0;

            Console.WriteLine("Hi I am before catch!");

            try
            {
                Console.WriteLine("a :"+a);
                Console.WriteLine("b :" + b);
                c = a / (b - 5);
                Console.WriteLine("Hi, I calculated the value of c without any problem.");
                Console.WriteLine("c :" + c);
            }
            catch(Exception e)
            {
                Console.WriteLine("I am with in catch error : " + e.Message.ToString());
                c = a / b;
                Console.WriteLine("c :" + c);
            }
            Console.WriteLine("I am outside the catch block.");
            Console.ReadKey();
        }
        

    }
}
