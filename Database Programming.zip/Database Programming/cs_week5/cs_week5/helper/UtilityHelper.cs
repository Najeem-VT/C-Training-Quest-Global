﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cs_week5.helper
{
    class UtilityHelper
    {

        public static string GenerateID(string oldId)
        {
            string newId = null;
            string prefix, suffix;
            int next;
            try
            {
                
                prefix = oldId.Substring(0,3);
                suffix = oldId.Substring(3);
                next = Convert.ToInt32(suffix)+1;
                newId = prefix + next;


            }
            catch (Exception ex)
            {
                Console.Out.WriteLine("Error : UtilityHelper:GenerateID : " + ex.Message.ToString());
            }
            return newId;
        }
    }
}
