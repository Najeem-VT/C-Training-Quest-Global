﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using cs_week5.dto;
using cs_week5.bl;

namespace cs_week5.Student
{
    public partial class StudentMaster : Form
    {
       
        int countMark1 = 0; bool flagMark1 = false;
        int countMark2 = 0; bool flagMark2 = false;
        int countMark3 = 0; bool flagMark3 = false;

        public StudentMaster()
        {
            InitializeComponent();
        }

        private void LoadStudentIds()
        {
            DataSet dsStudentIds = null;
            try
            {
                dsStudentIds = StudentMarkBl.GetStudentIds();
                if (dsStudentIds != null)
                {
                    cmbStudentID.DataSource = dsStudentIds.Tables[0];
                    cmbStudentID.ValueMember = "student_id";
                    cmbStudentID.DisplayMember = "student_id";
                    
                }
                else
                {
                    lblMessage.Text = "No Students Available!";
                }
            }
            catch(Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }

        }
        
        //private void btnSave_Click(object sender, EventArgs e)
        //{
        //SqlConnection con = null;
        //SqlCommand cmd = null;
        //String ConnectionString = null;
        //String sql = null;
        //String student_id, student_name, result;
        //int mark1, mark2, mark3, total;

        //int output = 0;

        //try
        //{
        //    ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\1028259\\Desktop\\NAJEEM\\Database Programming\\cs_week5\\cs_week5\\StudentDB.mdf;Integrated Security=True";
        //    con = new SqlConnection(ConnectionString);

        //    student_id = txtID.Text;
        //    student_name = txtName.Text;
        //    mark1 = Convert.ToInt32(txtMark1.Text);
        //    mark2 = Convert.ToInt32(txtMark2.Text);
        //    mark3 = Convert.ToInt32(txtMark3.Text);

        //    total = mark1 + mark2 + mark3;
        //    if (mark1 < 50 || mark2 < 50 || mark3 < 50)
        //    {
        //        result = "FAIL";
        //    }
        //    else
        //    {
        //        result = "PASS";
        //    }

        //    sql = "insert into student_mark(student_id,student_name,mark1,mark2,mark3,total,result) values(";
        //    sql =sql+"'"+student_id+"',";
        //    sql = sql + "'" + student_name + "',";
        //    sql = sql + mark1 + ",";
        //    sql = sql +mark2 + ",";
        //    sql = sql +  mark3 + ",";
        //    sql = sql +total + ",";
        //    sql = sql + "'" + result + "')";

        //    con.Open();
        //    cmd = new SqlCommand(sql,con);

        //    output = cmd.ExecuteNonQuery();
        //    if (output > 0)
        //    {
        //        lblMessage.Text = "Success!";
        //    }
        //    else
        //    {
        //        lblMessage.Text = "Failed!";
        //    }

        //}
        //catch(Exception ex)
        //{
        //    lblMessage.Text = ex.Message.ToString();
        //}
        //finally
        //{
        //    con.Close();
        //    cmd.Dispose();
        //}

        //}
        private void btnSave_Click(object sender, EventArgs e)
        {
            StudentMark studentMark=null;
            int output =0;

            try
            {
                if (btnSave.Text == "NEW")
                {
                    btnSave.Text = "SAVE";
                    ClearControl();
                    txtID.Text = StudentMarkBl.GetNewStudentId();

                    btnDelete.Enabled = false;
                    btnUpdate.Enabled = false;
                    btnClear.Text = "BACK";
                }
                else
                {
                    studentMark = new StudentMark();
                    studentMark.StudentID = txtID.Text;
                    studentMark.StudentName = txtName.Text;
                    studentMark.Mark1 = Convert.ToInt32(txtMark1.Text);
                    studentMark.Mark2 = Convert.ToInt32(txtMark2.Text);
                    studentMark.Mark3 = Convert.ToInt32(txtMark3.Text);

                    if (studentMark.Mark1 < 0 || studentMark.Mark1 > 100 || studentMark.Mark2 < 0 || studentMark.Mark2 > 100 || studentMark.Mark3 < 0 || studentMark.Mark3 > 100)
                    {
                        lblMessage.Text = "Marks should be in the range of 0 - 100";
                        txtMark1.Focus();
                    }
                    else
                    {
                        output = StudentMarkBl.StudentInsertMark(studentMark);

                        if (output > 0)
                        {
                            LoadStudentIds();
                            LoadStudents();
                            btnSave.Text = "NEW";
                            btnDelete.Enabled = true;
                            btnUpdate.Enabled = true;
                            btnClear.Text = "CLEAR";
                            lblMessage.Text = "Details Added Successfully!";

                        }
                        else
                        {
                            lblMessage.Text = "Failed! Please Try Again.";
                        }
                    }
               

                }

            }
            catch (FormatException ex)
            {
                lblMessage.Text = "Kindly Enter a Numeric Value";
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }
        }

        private void StudentMaster_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'studentDBDataSet.student_mark' table. You can move, or remove it, as needed.
            this.student_markTableAdapter.Fill(this.studentDBDataSet.student_mark);
            LoadStudentIds();
            LoadStudents();

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            if (btnClear.Text == "BACK")
            {
                btnSave.Text = "NEW";
                btnDelete.Enabled = true;
                btnUpdate.Enabled = true;
                btnClear.Text = "CLEAR";
            }
            else
            {
                ClearControl();
            }      
        }

        private void cmbStudentID_SelectedIndexChanged(object sender, EventArgs e)
        {
            //MessageBox.Show(cmbStudentID.Text);

            StudentMark studentMark = null;
            try
            {
                
                studentMark= StudentMarkBl.GetStudentByIds(cmbStudentID.Text);
                if (studentMark != null)
                {
                    txtID.Text = studentMark.StudentID;
                    txtName.Text = studentMark.StudentName.ToString();
                    txtMark1.Text = studentMark.Mark1.ToString();
                    txtMark2.Text = studentMark.Mark2.ToString();
                    txtMark3.Text = studentMark.Mark3.ToString();
                }
               
            }
            catch(Exception ex)
            {
              lblMessage.Text = ex.Message.ToString();
            }

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int output = 0;
            try
            {
                if (MessageBox.Show("Do you want to delete?","Student Details",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)
                {
                    output = StudentMarkBl.StudentMarkDelete(cmbStudentID.Text);
                    if (output > 0)
                    {
                        LoadStudentIds();
                        LoadStudents();
                        lblMessage.Text = "Student Details Deleted Successfully.";

                    }
                    else
                    {
                        lblMessage.Text = "Please Try Again Later.";
                    }
                }
                else
                {
                    lblMessage.Text = "Please Try Again Later.";
                }


            }
            catch(Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            StudentMark studentMark = null;
            int output = 0;

            try
            {
                studentMark = new StudentMark();
                studentMark.StudentID = txtID.Text;
                studentMark.StudentName = txtName.Text;
                studentMark.Mark1 = Convert.ToInt32(txtMark1.Text);
                studentMark.Mark2 = Convert.ToInt32(txtMark2.Text);
                studentMark.Mark3 = Convert.ToInt32(txtMark3.Text);

                if (studentMark.Mark1 < 0 || studentMark.Mark1 > 100 || studentMark.Mark2 < 0 || studentMark.Mark2 > 100 || studentMark.Mark3 < 0 || studentMark.Mark3 > 100)
                {
                    lblMessage.Text = "Marks should be in the range of 0 - 100";
                }
                else
                {
                    output = StudentMarkBl.StudentMarkUpdate(studentMark);

                    if (output > 0)
                    {
                        LoadStudentIds();
                        LoadStudents();
                        lblMessage.Text = "Updated Successfully.";
                        
                    }
                    else
                    {
                        lblMessage.Text = "Please Try Again";
                    }

                }
            }
            catch (FormatException ex)
            {
                lblMessage.Text = "Kindly Enter a Numeric Value";
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }
        }


        private void LoadStudents()
        {
            DataSet dsStudents = null;
            try
            {
                dsStudents = StudentMarkBl.GetStudents();
                if (dsStudents != null)
                {
                    dgvStudent.DataSource = dsStudents.Tables[0];
                  
                }
                else
                {
                    lblMessage.Text = "No Students Available!";
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }

        }

        private void ClearControl()
        {
            txtMark1.Text = "";
            txtMark2.Text = "";
            txtMark3.Text = "";
            txtID.Text = "";
            txtName.Text = "";
            lblMessage.Text = "";
        }

        private void txtNameSearch_TextChanged(object sender, EventArgs e)
        {
            DataSet dsStudents = null;
            try
            {
                string nameLike = txtNameSearch.Text;
                dsStudents = StudentMarkBl.GetStudentsLike(nameLike);
                if (dsStudents != null)
                {
                    dgvStudent.DataSource = dsStudents.Tables[0];
                }
                else
                {
                    lblMessage.Text = "No Students Available!";
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.Message.ToString();
            }

        }

        private void txtMark1_KeyDown(object sender, KeyEventArgs e)
        {
            flagMark1 = false;

            if (!txtMark1.Text.Contains(".") && countMark1 > 0)
            {
                countMark1--;
            }

            if ((e.KeyCode>=Keys.D0 && e.KeyCode <= Keys.D9)||
                    (e.KeyCode >= Keys.NumPad0 && e.KeyCode <= Keys.NumPad9)||
                    ((e.KeyCode == Keys.Decimal || e.KeyCode == Keys.OemPeriod) && countMark1<1)||
                    e.KeyCode == Keys.Back)
            {
                flagMark1 = true;
                if (e.KeyCode == Keys.Decimal || e.KeyCode == Keys.OemPeriod)
                {
                    countMark1++;
                }
            }
            
        }

        private void txtMark1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!flagMark1)
            {
                e.Handled = true;
            }
        }

        private void txtMark2_KeyDown(object sender, KeyEventArgs e)
        {
            flagMark2 = false;

            if (!txtMark2.Text.Contains(".") && countMark2 > 0)
            {
                countMark2--;
            }

            if ((e.KeyCode >= Keys.D0 && e.KeyCode <= Keys.D9) ||
                    (e.KeyCode >= Keys.NumPad0 && e.KeyCode <= Keys.NumPad9) ||
                    ((e.KeyCode == Keys.Decimal || e.KeyCode == Keys.OemPeriod) && countMark2 < 1) ||
                    e.KeyCode == Keys.Back)
            {
                flagMark2 = true;
                if (e.KeyCode == Keys.Decimal || e.KeyCode == Keys.OemPeriod)
                {
                    countMark2++;
                }
            }
        }

        private void txtMark2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!flagMark2)
            {
                e.Handled = true;
            }
        }

        private void txtMark3_KeyDown(object sender, KeyEventArgs e)
        {
            flagMark3 = false;

            if (!txtMark3.Text.Contains(".") && countMark3 > 0)
            {
                countMark3--;
            }

            if ((e.KeyCode >= Keys.D0 && e.KeyCode <= Keys.D9) ||
                    (e.KeyCode >= Keys.NumPad0 && e.KeyCode <= Keys.NumPad9) ||
                    ((e.KeyCode == Keys.Decimal || e.KeyCode == Keys.OemPeriod) && countMark3 < 1) ||
                    e.KeyCode == Keys.Back)
            {
                flagMark3 = true;
                if (e.KeyCode == Keys.Decimal || e.KeyCode == Keys.OemPeriod)
                {
                    countMark3++;
                }
            }
        }

        private void txtMark3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!flagMark3)
            {
                e.Handled = true;
            }
        }

        private void dgvStudent_SelectionChanged(object sender, EventArgs e)
        {
            String studentId, student_name;
            int mark1, mark2, mark3;

            if (dgvStudent.SelectedCells.Count > 0)
            {
                int selectedrowindex = dgvStudent.SelectedCells[0].RowIndex;

                DataGridViewRow selectedRow = dgvStudent.Rows[selectedrowindex];

                studentId=Convert.ToString(selectedRow.Cells["student_id"].Value);
                student_name= Convert.ToString(selectedRow.Cells["student_name"].Value);
                mark1 = Convert.ToInt32(selectedRow.Cells["mark1"].Value);
                mark2 = Convert.ToInt32(selectedRow.Cells["mark2"].Value);
                mark3 = Convert.ToInt32(selectedRow.Cells["mark3"].Value);

                txtID.Text = studentId;
                txtName.Text = student_name;
                txtMark1.Text = mark1.ToString();
                txtMark1.Text = mark2.ToString();
                txtMark1.Text = mark3.ToString();
            }
        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {

        }

        private void dgvStudent_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
