﻿CREATE TABLE [dbo].[student_personal]
(
	[student_id] VARCHAR(50) NOT NULL PRIMARY KEY, 
    [email] VARCHAR(150) NOT NULL, 
    [mobileNumber] INT NOT NULL, 
    [address] VARCHAR(500) NOT NULL, 
    [dob] Date NOT NULL, 
)
