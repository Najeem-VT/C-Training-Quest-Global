﻿INSERT INTO [dbo].[student_mark] ([student_id], [student_name], [mark1], [mark2], [mark3], [total], [result]) VALUES (N'STU101', N'NAJEEM', 50, 60, 60, 170, N'PASS')
INSERT INTO [dbo].[student_mark] ([student_id], [student_name], [mark1], [mark2], [mark3], [total], [result]) VALUES (N'STU102', N'GOKUL', 40, 40, 40, 120, N'PASS')
INSERT INTO [dbo].[student_mark] ([student_id], [student_name], [mark1], [mark2], [mark3], [total], [result]) VALUES (N'STU103', N'RAVI', 30, 20, 40, 90, N'FAIL')
