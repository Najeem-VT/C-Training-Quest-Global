﻿namespace LINQUDemo
{
    partial class LinqArray
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLoadNumbers = new System.Windows.Forms.Button();
            this.cmbNumbers = new System.Windows.Forms.ComboBox();
            this.cmbNames = new System.Windows.Forms.ComboBox();
            this.btnLoadNames = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnLoadNumbers
            // 
            this.btnLoadNumbers.Location = new System.Drawing.Point(61, 161);
            this.btnLoadNumbers.Name = "btnLoadNumbers";
            this.btnLoadNumbers.Size = new System.Drawing.Size(97, 44);
            this.btnLoadNumbers.TabIndex = 0;
            this.btnLoadNumbers.Text = "Load Numbers";
            this.btnLoadNumbers.UseVisualStyleBackColor = true;
            this.btnLoadNumbers.Click += new System.EventHandler(this.btnLoadNumbers_Click);
            // 
            // cmbNumbers
            // 
            this.cmbNumbers.FormattingEnabled = true;
            this.cmbNumbers.Location = new System.Drawing.Point(39, 47);
            this.cmbNumbers.Name = "cmbNumbers";
            this.cmbNumbers.Size = new System.Drawing.Size(158, 21);
            this.cmbNumbers.TabIndex = 1;
            // 
            // cmbNames
            // 
            this.cmbNames.FormattingEnabled = true;
            this.cmbNames.Location = new System.Drawing.Point(245, 47);
            this.cmbNames.Name = "cmbNames";
            this.cmbNames.Size = new System.Drawing.Size(164, 21);
            this.cmbNames.TabIndex = 2;
            // 
            // btnLoadNames
            // 
            this.btnLoadNames.Location = new System.Drawing.Point(267, 161);
            this.btnLoadNames.Name = "btnLoadNames";
            this.btnLoadNames.Size = new System.Drawing.Size(97, 44);
            this.btnLoadNames.TabIndex = 3;
            this.btnLoadNames.Text = "Load Names";
            this.btnLoadNames.UseVisualStyleBackColor = true;
            this.btnLoadNames.Click += new System.EventHandler(this.btnLoadNames_Click);
            // 
            // LinqArray
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnLoadNames);
            this.Controls.Add(this.cmbNames);
            this.Controls.Add(this.cmbNumbers);
            this.Controls.Add(this.btnLoadNumbers);
            this.Name = "LinqArray";
            this.Text = "LinqArray";
            this.Load += new System.EventHandler(this.LinqArray_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnLoadNumbers;
        private System.Windows.Forms.ComboBox cmbNumbers;
        private System.Windows.Forms.ComboBox cmbNames;
        private System.Windows.Forms.Button btnLoadNames;
    }
}