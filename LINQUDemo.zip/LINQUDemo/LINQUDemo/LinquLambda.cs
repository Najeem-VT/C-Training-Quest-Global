﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LINQUDemo
{

  
    public partial class LinquLambda : Form
    {
        Student[] studentArray =
    {
            new Student(){ StudentID=1,StudentName="Hari",Age=12},
            new Student(){ StudentID=2,StudentName="Ravi",Age=15},
            new Student(){ StudentID=3,StudentName="Gopi",Age=19},
            new Student(){ StudentID=4,StudentName="Shyam",Age=32},
            new Student(){ StudentID=5,StudentName="Roy",Age=56}
        };
        public LinquLambda()
        {
            InitializeComponent();
        }

        private void LinquLambda_Load(object sender, EventArgs e)
        {

        }

        private void btnLambda1_Click(object sender, EventArgs e)
        {
            List<Student> teenAgers = studentArray.Where(s => s.Age > 12 && s.Age < 20).ToList();
            dgvView.DataSource = teenAgers;
        }

        private void btnLambda2_Click(object sender, EventArgs e)
        {
            List<Student> teenAgers = studentArray.Where(s => s.StudentName=="Ravi").ToList();
            dgvView.DataSource = teenAgers;
        }

        private void btnLambda3_Click(object sender, EventArgs e)
        {
            List<Student> teenAgers = studentArray.Where(s => s.StudentID==5).ToList();
            dgvView.DataSource = teenAgers;
        }
    }

    class Student
    {
        public int StudentID { get; set; }
        public string StudentName { get; set; }
        public int Age { get; set; }
    }

}

    