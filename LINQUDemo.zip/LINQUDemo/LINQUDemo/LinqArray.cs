﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LINQUDemo
{
    public partial class LinqArray : Form
    {
        public LinqArray()
        {
            InitializeComponent();
        }

        private void LinqArray_Load(object sender, EventArgs e)
        {
            
            //LoadNumbers();
        }

        private void LoadNumbers()
        {
            int[] Numbers = {1,2,3,4,5,6,7,8,9};
            var LiqQuery = from num in Numbers
                           where (num % 2) == 0
                           select num;
            List<int> lstNumbers = LiqQuery.ToList();
            //foreach(int val in lstNumbers)
            //{
            //    Console.WriteLine("Val:"+val);
            //}

            //foreach (int val in lstNumbers)
            //{
            //    cmbNumbers.Items.Add(val);
            //}

            cmbNumbers.DataSource = LiqQuery.ToList();
        }


        private void LoadNames()
        {
            string[] names = {"Bill","Steve","James","Mohan" };

            var myLinqQuery = from name in names
                              where name.Contains('e')
                              select name;

            cmbNames.DataSource = myLinqQuery.ToList();

        }
            private void btnLoadNumbers_Click(object sender, EventArgs e)
        {
            LoadNumbers();
        }

        private void btnLoadNames_Click(object sender, EventArgs e)
        {
            LoadNames();
        }
    }
}
