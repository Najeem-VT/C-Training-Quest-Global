﻿namespace LINQUDemo
{
    partial class Linq_Xml
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvDispaly = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDispaly)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvDispaly
            // 
            this.dgvDispaly.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDispaly.Location = new System.Drawing.Point(46, 77);
            this.dgvDispaly.Name = "dgvDispaly";
            this.dgvDispaly.Size = new System.Drawing.Size(744, 386);
            this.dgvDispaly.TabIndex = 0;
            // 
            // Linq_Xml
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(842, 519);
            this.Controls.Add(this.dgvDispaly);
            this.Name = "Linq_Xml";
            this.Text = "Linq_Xml";
            this.Load += new System.EventHandler(this.Linq_Xml_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDispaly)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvDispaly;
    }
}